"""Online pickup-and-delivery simulator on factory road graphs. No mjlab or torch."""
