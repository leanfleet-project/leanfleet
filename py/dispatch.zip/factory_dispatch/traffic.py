"""Shared motion rule: PIBT (Okumura et al.) on the one-lane, two-way road graph.

All methods use it, so differences between them come from assignment alone. Each
tick every agent moves to a neighbour or stays. There are never vertex or swap
conflicts. A low-priority agent in the way is pushed aside.
"""

from __future__ import annotations

from collections import deque

from factory_layout import RoadGraph
from factory_layout.layout import Cell

UNREACHABLE = 10**9


class RoadIndex:
  """Integer ids for road cells, plus cached BFS distance tables."""

  def __init__(self, graph: RoadGraph) -> None:
    self.graph = graph
    self.cells: list[Cell] = sorted(graph.all_cells())
    self.ids: dict[Cell, int] = {c: i for i, c in enumerate(self.cells)}
    self.nbrs: list[list[int]] = [
      [self.ids[n] for n in graph.neighbours(c)] for c in self.cells
    ]
    self._dist: dict[int, list[int]] = {}
    self.blocked: frozenset[int] = frozenset()
    self.zone: list[int] = _dead_end_zones(self.nbrs)
    """Dead-end zone id per cell (-1: on a cycle or a through road). A zone is a
    connected set of cells that only lead to dead ends."""

  def set_blocked(self, ids) -> None:
    """Cells nobody may enter. Distances route around them; a blocked target is
    unreachable. Clears the distance cache when the set changes. Dead-end zones are
    recomputed too: a block can turn a through road into a dead end for a while."""
    ids = frozenset(ids)
    if ids != self.blocked:
      self.blocked = ids
      self._dist.clear()
      open_nbrs = [[] if i in ids else [n for n in ns if n not in ids]
                   for i, ns in enumerate(self.nbrs)]
      self.zone = _dead_end_zones(open_nbrs)
      for i in ids:
        self.zone[i] = -1

  def dist_to(self, target: int) -> list[int]:
    table = self._dist.get(target)
    if table is None:
      table = [UNREACHABLE] * len(self.cells)
      table[target] = 0
      queue = deque([] if target in self.blocked else [target])
      blocked = self.blocked
      while queue:
        c = queue.popleft()
        for n in self.nbrs[c]:
          if table[n] == UNREACHABLE and n not in blocked:
            table[n] = table[c] + 1
            queue.append(n)
      self._dist[target] = table
    return table


def _dead_end_zones(nbrs: list[list[int]]) -> list[int]:
  """Peel degree-1 cells repeatedly; what peels off are dead-end branches. Each
  connected group of peeled cells is one zone. A layout that is all tree has none."""
  n = len(nbrs)
  deg = [len(x) for x in nbrs]
  peeled = [False] * n
  queue = deque(i for i in range(n) if deg[i] <= 1)
  while queue:
    c = queue.popleft()
    if peeled[c]:
      continue
    peeled[c] = True
    for nb in nbrs[c]:
      if not peeled[nb]:
        deg[nb] -= 1
        if deg[nb] <= 1:
          queue.append(nb)
  zone = [-1] * n
  if all(peeled):
    return zone
  count = 0
  for start in range(n):
    if peeled[start] and zone[start] < 0:
      zone[start] = count
      stack = [start]
      while stack:
        c = stack.pop()
        for nb in nbrs[c]:
          if peeled[nb] and zone[nb] < 0:
            zone[nb] = count
            stack.append(nb)
      count += 1
  return zone


class Traffic:
  def __init__(
    self, index: RoadIndex, zone_lock: bool = False, gap: int = 0, patience: int | None = 10,
  ) -> None:
    """`gap`: 1 keeps one empty cell between AGVs: nobody moves next to another AGV
    (an AGV standing still may stay where it is). 0 is the original rule.
    `patience`: with the gap on, an AGV that has waited this many ticks for its goal
    may close in on another one (creep mode); the original rule then plans it and
    may push others the same way. A
    strict gap can never let two AGVs serve neighbouring stations and gridlocks dense
    traffic. None keeps the gap strict. `relaxed` lists who crept on the last step.
    `zone_lock`: at most one agent inside each dead-end zone (zone control, as
    plants do for one-lane dead ends). Without it, agents queued in a dead end
    can deadlock: the one inside cannot get out past those waiting to get in."""
    self.index = index
    self.zone_lock = zone_lock
    if gap not in (0, 1):
      raise ValueError("gap must be 0 or 1")
    self.gap = gap
    self.patience = patience
    self.wait: list[int] = []
    self.relaxed: list[int] = []

  def step(
    self, positions: list[int], goals: list[int | None], priorities: list[float],
    prefer: list[int | None] | None = None,
  ) -> list[int]:
    """Next cell id per agent. Higher priority plans first and can push others.
    `prefer`: a cell to try first per agent (its planned route); the rest follow."""
    nbrs = self.index.nbrs
    blocked = self.index.blocked
    here = {p: i for i, p in enumerate(positions)}
    taken: dict[int, int] = {}
    nxt: list[int | None] = [None] * len(positions)
    zone = self.index.zone if self.zone_lock else None
    busy = {zone[p] for p in positions if zone[p] >= 0} if zone else set()

    def plan(i: int, pusher: int | None) -> bool:
      pos = positions[i]
      goal = goals[i]
      if goal is None:
        options = [pos] + nbrs[pos]
      else:
        table = self.index.dist_to(goal)
        # Stable sort: ties keep neighbour order, and staying loses ties.
        options = sorted(nbrs[pos] + [pos], key=table.__getitem__)
        if prefer is not None and prefer[i] is not None:
          options.remove(prefer[i])
          options.insert(0, prefer[i])
      for c in options:
        if c in taken or (c in blocked and c != pos):
          continue
        if pusher is not None and c == positions[pusher]:
          continue  # Would swap with the agent pushing us.
        entering = -1
        if zone is not None and zone[c] >= 0 and zone[c] != zone[pos]:
          if zone[c] in busy or goal is None or zone[goal] != zone[c]:
            continue  # Taken, or not where we are going: never an escape route.
          entering = zone[c]
          busy.add(entering)
        taken[c] = i
        nxt[i] = c
        k = here.get(c)
        if k is None or k == i or nxt[k] is not None:
          return True
        if plan(k, i):
          return True
        del taken[c]
        nxt[i] = None
        if entering >= 0:
          busy.discard(entering)
      taken[pos] = i
      nxt[i] = pos
      return False

    # With zone lock, an agent whose goal lies in a zone someone else holds plans
    # last: it can only wait, and it must not hold the mouth against the one
    # coming out.
    def order(a: int) -> tuple:
      g = goals[a]
      held = (
        zone is not None and g is not None and zone[g] >= 0
        and zone[g] != zone[positions[a]] and zone[g] in busy
      )
      # Leaving a dead-end zone goes first, so whoever queued in front backs out.
      # Without it, a block that closes behind an AGV traps it with its queue.
      leaving = (
        zone is not None and g is not None and zone[positions[a]] >= 0
        and zone[g] != zone[positions[a]]
      )
      return (held, not leaving, -priorities[a], a)

    active: set[int] = set()

    def plan_gap(i: int, avoid: int | None) -> bool:
      """Safety-gap PIBT. `avoid`: we were asked to clear the way for someone who
      wants to enter `avoid`, so we must move to a cell not next to it. Returns
      True if the agent moves."""
      active.add(i)
      pos = positions[i]
      goal = goals[i]
      if goal is None:
        options = [pos] + nbrs[pos]
      else:
        table = self.index.dist_to(goal)
        options = sorted(nbrs[pos] + [pos], key=table.__getitem__)
        if prefer is not None and prefer[i] is not None:
          options.remove(prefer[i])
          options.insert(0, prefer[i])
      if avoid is not None:
        options = [c for c in options if c != avoid and c not in nbrs[avoid] and c != pos]
      for c in options:
        if c == pos:
          break
        if c in taken or c in blocked:
          continue
        if zone is not None and zone[c] >= 0 and zone[c] != zone[pos] and (
          zone[c] in busy or goal is None or zone[goal] != zone[c]
        ):
          continue
        k = here.get(c)
        if k is not None and k != i:
          # Occupied: ask it to move away and hold here; we enter on a later tick.
          if avoid is not None or nxt[k] is not None or k in active:
            continue
          taken[pos] = i
          nxt[i] = pos
          if plan_gap(k, None) and nxt[k] != c:
            active.discard(i)
            return False
          del taken[pos]
          nxt[i] = None
          continue
        ok = True
        for n in nbrs[c]:
          if n == pos:
            continue
          t = taken.get(n)
          if t is not None and t != i:
            ok = False
            break
          j = here.get(n)
          if j is not None and j != i and nxt[j] is None:
            if j in active or not plan_gap(j, c):
              ok = False
              break
        if not ok or c in taken:
          continue
        if zone is not None and zone[c] >= 0 and zone[c] != zone[pos]:
          if zone[c] in busy:
            continue
          busy.add(zone[c])
        taken[c] = i
        nxt[i] = c
        active.discard(i)
        return True
      taken[pos] = i
      nxt[i] = pos
      active.discard(i)
      return False

    n = len(positions)
    if len(self.wait) != n:
      self.wait = [0] * n
    creep = {
      i for i in range(n)
      if self.gap and self.patience is not None and self.wait[i] >= self.patience
    }
    for i in sorted(range(n), key=order):
      if nxt[i] is None:
        if self.gap and i not in creep:
          plan_gap(i, None)
        else:
          plan(i, None)
    for i in range(n):
      g = goals[i]
      self.wait[i] = self.wait[i] + 1 if g is not None and g != positions[i] and nxt[i] == positions[i] else 0
    # Everyone who ended next to another AGV by moving: creepers and whoever a
    # creeper pushed under the original rule.
    self.relaxed = sorted(
      i for i in range(n)
      if nxt[i] != positions[i] and any(nxt[j] in nbrs[nxt[i]] for j in range(n) if j != i)
    )
    return nxt  # type: ignore[return-value]
