"""Fixed-route baseline: each AGV circulates its predefined loop (layouts b)."""

from __future__ import annotations

from factory_dispatch.insertion import MAX_COMMITTED, Stop
from factory_dispatch.orders import Order
from factory_dispatch.sim import Dispatcher, SimView
from factory_layout import FactoryLayout, build_road_graph
from factory_layout.layout import Cell

# Direction codes: 0 right, 1 up, 2 left, 3 down, as (row, col) steps.
_STEP = {0: (0, 1), 1: (-1, 0), 2: (0, -1), 3: (1, 0)}


def route_cycle(layout: FactoryLayout, agv: int) -> list[Cell]:
  """Walk the turn codes from the AGV's store until it is back there.

  A code is consumed only where more than one way forward exists; 1 straight,
  2 left, 3 right. With no way forward the AGV turns around.
  """
  graph = build_road_graph(layout)
  home = layout.stores[str(agv + 1)][0]
  codes = layout.agv_routes[agv]
  cell, heading = home, layout.agv_orient[agv]
  used = 0
  path = [home]
  for _ in range(20 * (layout.grid == 1).sum()):
    nbrs = set(graph.neighbours(cell))
    forward = {}
    for code, turn in ((1, 0), (2, 1), (3, -1)):
      d = (heading + turn) % 4
      c = (cell[0] + _STEP[d][0], cell[1] + _STEP[d][1])
      if c in nbrs:
        forward[code] = (c, d)
    if not forward:
      d = (heading + 2) % 4
      next_cell = (cell[0] + _STEP[d][0], cell[1] + _STEP[d][1])
      heading = d
    elif len(forward) == 1:
      next_cell, heading = next(iter(forward.values()))
    else:
      code = codes[used % len(codes)]
      used += 1
      if code not in forward:
        raise ValueError(f"AGV {agv}: code {code} invalid at {cell} on {layout.name}")
      next_cell, heading = forward[code]
    path.append(next_cell)
    cell = next_cell
    if cell == home and used % len(codes) == 0:
      return path
  raise ValueError(f"AGV {agv}: route never returns to its store on {layout.name}")


class FixedRouteDispatcher(Dispatcher):
  """An order goes to an AGV whose loop passes its pickup and dropoff."""

  def __init__(self, layout: FactoryLayout) -> None:
    self.cycles = [route_cycle(layout, a) for a in range(len(layout.agv_routes))]
    self._sets = [set(c) for c in self.cycles]
    self._waiting: list[list[Order]] = [[] for _ in self.cycles]
    self.unservable = 0
    self._counted: set[int] = set()

  def decide(self, view: SimView) -> list[tuple[int, int]]:
    return []

  def replan(self, view: SimView) -> dict[int, list[Stop]] | None:
    plan: dict[int, list[Stop]] = {}
    for o in view.pending:
      options = [
        a
        for a in view.agvs
        if o.pickup in self._sets[a.id] and o.dropoff in self._sets[a.id]
      ]
      if not options:
        if o.id not in self._counted:
          self._counted.add(o.id)
          self.unservable += 1
        continue
      held = lambda a: a.load + sum(s.kind == "pick" for s in plan.get(a.id, a.stops))  # noqa: E731
      room = [a for a in options if held(a) < MAX_COMMITTED]
      if not room:
        continue
      a = min(room, key=lambda x: (held(x), x.id))
      plan[a.id] = self._route(view, a, o, plan.get(a.id, a.stops))
    return plan or None

  def _route(self, view, agv, order, stops) -> list[Stop]:
    """Rebuild the stop list along the loop, adding the new order."""
    cycle = self.cycles[agv.id]
    vias = [s for s in stops if s.kind == "via"]
    start = vias[0].order_id if vias else self._nearest_index(cycle, agv.cell)
    drops = {s.order_id: s.cell for s in stops if s.kind == "drop"}
    picks = {s.order_id: s.cell for s in stops if s.kind == "pick"}
    on_board = [i for i in drops if i not in picks]
    waiting = dict(picks)
    waiting[order.id] = order.pickup
    drops[order.id] = order.dropoff
    carrying = set(on_board)
    out: list[Stop] = []
    i = start
    # Two full laps are always enough: one to pick up, one to drop off.
    for _ in range(3 * len(cycle)):
      if not waiting and not carrying:
        break
      cell = cycle[i]
      out.append(Stop(i, "via", cell))
      for oid in [k for k in carrying if drops[k] == cell]:
        out.append(Stop(oid, "drop", cell))
        carrying.discard(oid)
      for oid in [k for k, c in waiting.items() if c == cell]:
        if len(carrying) < view.q:
          out.append(Stop(oid, "pick", cell))
          carrying.add(oid)
          del waiting[oid]
      i = (i + 1) % (len(cycle) - 1)
    return out

  @staticmethod
  def _nearest_index(cycle: list[Cell], cell: Cell) -> int:
    return min(
      range(len(cycle) - 1),
      key=lambda i: abs(cycle[i][0] - cell[0]) + abs(cycle[i][1] - cell[1]),
    )
