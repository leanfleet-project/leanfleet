"""Plan-aware routing: choose the path that arrives first given known stops.

Where and when every AGV will stop to load or unload is part of the plan, and a
stopped AGV holds its cell on the one-lane road. So an AGV's route is computed
against those windows, and going around or waiting is whichever arrives earlier.
PIBT still resolves AGV-AGV conflicts tick by tick.
"""

from __future__ import annotations

import heapq

from factory_dispatch.insertion import Stop, dwell
from factory_dispatch.orders import Order
from factory_dispatch.traffic import UNREACHABLE, RoadIndex

Windows = dict[int, list[tuple[int, int]]]
"""Cell id -> [(start, end)): times another AGV is stopped on that cell."""


def _enter(cell: int, t: int, windows: Windows) -> int:
  """Earliest time at or after `t` that `cell` can be entered."""
  for a, b in windows.get(cell, ()):
    if a <= t < b:
      t = b
  return t


def timed_route(
  index: RoadIndex, start: int, goal: int, t0: int, windows: Windows
) -> tuple[int, list[int]] | None:
  """A* over cells with time-dependent, first-in-first-out entry times. Returns
  (arrival, cells after `start`), or None if the goal is unreachable. Dead-end zones
  are only entered if the goal is inside: they are never a way around."""
  table = index.dist_to(goal)
  if table[start] >= UNREACHABLE:
    return None
  zone = index.zone
  own = (zone[start], zone[goal])
  best = {start: t0}
  came: dict[int, int] = {}
  heap = [(t0 + table[start], t0, start)]
  while heap:
    _, t, c = heapq.heappop(heap)
    if t > best[c]:
      continue
    if c == goal:
      path = [c]
      while path[-1] != start:
        path.append(came[path[-1]])
      return t, path[-2::-1] if len(path) > 1 else []
    for n in index.nbrs[c]:
      if table[n] >= UNREACHABLE or (zone[n] >= 0 and zone[n] not in own):
        continue
      nt = _enter(n, t + 1, windows)
      if nt < best.get(n, UNREACHABLE):
        best[n] = nt
        came[n] = c
        heapq.heappush(heap, (nt + table[n], nt, n))
  return None


def route_arrival(path: list[int], t0: int, windows: Windows) -> int:
  """Arrival time of an existing path under `windows`."""
  t = t0
  for c in path:
    t = _enter(c, t + 1, windows)
  return t


def forecast_windows(
  index: RoadIndex,
  now: int,
  pos: list[int],
  stops: list[list[Stop]],
  serving: list[tuple[Stop, int] | None],
  orders: dict[int, Order],
) -> list[Windows]:
  """Per AGV, when it will be stopped and where, walking its stop list at free-flow
  speed. An order not yet arrived holds the AGV only from its arrival, as in the
  simulator, where an early AGV yields instead of blocking."""
  out: list[Windows] = []
  for a, plan in enumerate(stops):
    w: Windows = {}
    here, t = pos[a], now
    rest = plan
    if serving[a] is not None:
      w[here] = [(now, serving[a][1])]
      t = serving[a][1]
      rest = plan[1:]
    for s in rest:
      target = index.ids[s.cell]
      leg = index.dist_to(target)[here]
      if leg >= UNREACHABLE:
        break
      t += leg
      here = target
      o = orders.get(s.order_id)
      if s.kind == "via" or o is None:
        continue
      if s.kind == "pick":
        t = max(t, o.arrival)
      w.setdefault(here, []).append((t, t + dwell(o)))
      t += dwell(o)
    out.append(w)
  return out


class TimedRouter:
  """Keeps one route per AGV. Routes change only when the plan changes, and only
  for a gain above `margin` seconds, so AGVs do not dither between equal options."""

  def __init__(self, index: RoadIndex, margin: int = 3, refresh: int = 10) -> None:
    self.index = index
    self.margin = margin
    self.refresh = refresh
    self.paths: dict[int, tuple[int, list[int]]] = {}
    self.signature = None
    self.windows: list[Windows] = []
    self.computed = -10**9

  def _on_route(self, a: int, goal: int, here: int) -> list[int] | None:
    entry = self.paths.get(a)
    if entry is None or entry[0] != goal:
      return None
    path = entry[1]
    if here in path:
      path = path[path.index(here) + 1:]
    elif not path or path[0] not in self.index.nbrs[here]:
      return None
    if any(c in self.index.blocked for c in path):
      return None
    self.paths[a] = (goal, path)
    return path

  def next_cells(
    self,
    now: int,
    pos: list[int],
    goals: list[int | None],
    stops: list[list[Stop]],
    serving: list[tuple[Stop, int] | None],
    orders: dict[int, Order],
  ) -> list[int | None]:
    """Preferred next cell per AGV; None leaves the choice to the traffic rule."""
    signature = (
      tuple(s[1] if s else -1 for s in serving),
      tuple(tuple((x.order_id, x.kind) for x in lst) for lst in stops),
      self.index.blocked,
    )
    changed = signature != self.signature or now - self.computed >= self.refresh
    if changed:
      self.windows = forecast_windows(self.index, now, pos, stops, serving, orders)
      self.signature = signature
      self.computed = now
    stopped_on = {pos[b] for b, s in enumerate(serving) if s is not None}
    out: list[int | None] = [None] * len(pos)
    for a, goal in enumerate(goals):
      if goal is None or goal == pos[a] or serving[a] is not None or not stops[a]:
        self.paths.pop(a, None)
        continue
      path = self._on_route(a, goal, pos[a])
      if path is None or changed:
        others: Windows = {}
        for b, w in enumerate(self.windows):
          if b != a:
            for c, spans in w.items():
              others.setdefault(c, []).extend(spans)
        for spans in others.values():
          spans.sort()
        found = timed_route(self.index, pos[a], goal, now, others)
        if found is None:
          self.paths.pop(a, None)
          continue
        arrival, fresh = found
        if path is None or arrival < route_arrival(path, now, others) - self.margin:
          path = fresh
          self.paths[a] = (goal, path)
      # Hold only for an AGV really stopped there. A forecast stop may never come
      # while we wait, and holding for it could block the very AGV we wait for.
      out[a] = pos[a] if path[0] in stopped_on else path[0]
    return out
