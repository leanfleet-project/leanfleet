"""Sequence an order into an AGV's stop list. Shared by every dispatcher.

Two capacities hold at every point of the sequence: at most MAX_COMMITTED orders
(on board plus assigned) and at most CAPACITY_TENTHS of workload on board.
Lateness is weighted by order priority.
"""

from __future__ import annotations

from dataclasses import dataclass

from factory_dispatch.orders import CAPACITY_TENTHS, PRIORITY_WEIGHT, SLOT_CAPACITY, Order
from factory_dispatch.traffic import UNREACHABLE, RoadIndex
from factory_layout.layout import Cell

TARDINESS_WEIGHT = 100
MAX_COMMITTED = 6
"""Orders one AGV may hold at once, on board plus assigned. Equal to its capacity;
beyond this, orders wait unassigned, which gives dispatchers something to decide."""

DWELL_BASE = 10
DWELL_PER_TRAY = 10
"""v2: seconds stopped at a pick or drop = DWELL_BASE + DWELL_PER_TRAY * trays."""


@dataclass(frozen=True)
class Rules:
  """Which problem version is simulated. v1 (default) keeps the original results
  reproducible; v2 is the author's 2026-11-06 problem (trays, dwell, J_lambda)."""

  v2: bool = False
  lam: float = 0.0
  """Weight of total flow time against weighted lateness in J_lambda."""


V1 = Rules()


def dwell(order: Order) -> int:
  return DWELL_BASE + DWELL_PER_TRAY * order.size


_EVALS = 0


def eval_count() -> int:
  """Calls to `evaluate` so far in this process. Dispatchers do almost all their
  work there, so the count is a deterministic, machine-free measure of compute."""
  return _EVALS


@dataclass(frozen=True)
class Stop:
  order_id: int
  kind: str  # "pick", "drop", or "via" (fixed-route waypoint)
  cell: Cell


@dataclass(frozen=True)
class Insertion:
  stops: list[Stop]
  added_travel: int
  added_tardiness: float
  """Weighted by priority."""
  added_flow: float = 0.0
  rules: Rules = V1

  @property
  def cost(self) -> float:
    if self.rules.v2:  # Exactly J_lambda; travel only breaks ties.
      return self.added_tardiness + self.rules.lam * self.added_flow + 1e-3 * self.added_travel
    return self.added_tardiness * TARDINESS_WEIGHT + self.added_travel


def on_board_tenths(stops: list[Stop], orders: dict[int, Order]) -> int:
  """Workload of orders whose drop is pending but whose pick is not."""
  picks = {s.order_id for s in stops if s.kind == "pick"}
  return sum(
    orders[s.order_id].size
    for s in stops
    if s.kind == "drop" and s.order_id not in picks and s.order_id in orders
  )


def evaluate(
  start: Cell,
  stops: list[Stop],
  load: int,
  q: int,
  now: int,
  index: RoadIndex,
  orders: dict[int, Order],
  rules: Rules = V1,
) -> tuple[int, float, float] | None:
  """(travel, weighted lateness, flow time) at free-flow speed; None if infeasible.

  v2 adds the dwell at every pick and drop and counts trays against SLOT_CAPACITY.
  Flow time sums (drop completion - arrival) over the orders dropped in `stops`."""
  global _EVALS
  _EVALS += 1
  here = index.ids[start]
  t = now
  travel = 0
  late = 0.0
  flow = 0.0
  cap = SLOT_CAPACITY if rules.v2 else CAPACITY_TENTHS
  tenths = on_board_tenths(stops, orders)
  for s in stops:
    target = index.ids[s.cell]
    leg = index.dist_to(target)[here]
    if leg >= UNREACHABLE:
      return None
    t += leg
    travel += leg
    here = target
    o = orders.get(s.order_id)
    if s.kind == "pick":
      load += 1
      if o is not None:
        t = max(t, o.arrival)  # Cannot load before the order exists.
        tenths += o.size
        if rules.v2:
          t += dwell(o)
      if load > q or tenths > cap:
        return None
    elif s.kind == "drop":
      load -= 1
      if o is not None:
        tenths -= o.size
        if rules.v2:
          t += dwell(o)
        late += PRIORITY_WEIGHT[o.priority] * max(0, t - o.deadline)
        flow += t - o.arrival
  return travel, late, flow


def stop_times(
  start: Cell, stops: list[Stop], now: int, index: RoadIndex, orders: dict[int, Order],
  rules: Rules = V1,
) -> list[int]:
  """Time each stop's service would start, at free-flow speed (same clock as
  `evaluate`). Unreachable stops get UNREACHABLE."""
  here = index.ids[start]
  t = now
  out = []
  for s in stops:
    target = index.ids[s.cell]
    leg = index.dist_to(target)[here]
    if leg >= UNREACHABLE:
      out.extend([UNREACHABLE] * (len(stops) - len(out)))
      return out
    t += leg
    here = target
    o = orders.get(s.order_id)
    if s.kind == "pick" and o is not None:
      t = max(t, o.arrival)
    out.append(t)
    if rules.v2 and o is not None and s.kind != "via":
      t += dwell(o)
  return out


def best_insertion(
  start: Cell,
  stops: list[Stop],
  load: int,
  order: Order,
  now: int,
  index: RoadIndex,
  q: int = 6,
  orders: dict[int, Order] | None = None,
  max_committed: int = MAX_COMMITTED,
  rules: Rules = V1,
) -> Insertion | None:
  """Cheapest feasible placement of the order, keeping the existing stop order.

  `orders` must contain every order in `stops` for capacity and lateness to count
  them; unknown orders count as size 0 with no deadline.
  """
  if order.size > (SLOT_CAPACITY if rules.v2 else CAPACITY_TENTHS):
    return None
  if load + sum(s.kind == "pick" for s in stops) >= max_committed:
    return None
  info = dict(orders or {})
  info[order.id] = order
  base = evaluate(start, stops, load, q, now, index, info, rules)
  if base is None:
    return None
  pick = Stop(order.id, "pick", order.pickup)
  drop = Stop(order.id, "drop", order.dropoff)
  best: Insertion | None = None
  for i in range(len(stops) + 1):
    for j in range(i, len(stops) + 1):
      trial = stops[:i] + [pick] + stops[i:j] + [drop] + stops[j:]
      got = evaluate(start, trial, load, q, now, index, info, rules)
      if got is None:
        continue
      cand = Insertion(trial, got[0] - base[0], got[1] - base[1], got[2] - base[2], rules)
      if best is None or cand.cost < best.cost:
        best = cand
  return best
