"""Recorders for `Simulation(recorders=[...])`: decision log, expert samples, trace.

They only read the state they are given; recording never changes a run.
"""

from __future__ import annotations

from factory_dispatch.insertion import MAX_COMMITTED
from factory_dispatch.orders import Order


def _order(o: Order) -> dict:
  return {
    "id": o.id, "pickup": o.pickup, "dropoff": o.dropoff, "arrival": o.arrival,
    "deadline": o.deadline, "priority": o.priority, "size": o.size,
  }


class DecisionLog:
  """One row per dispatcher call: state size, work and time it took."""

  def __init__(self) -> None:
    self.rows: list[dict] = []

  def decision(self, now, view, plan, pairs, evals, ms, delay, round) -> None:
    sizes = [len(a.stops) for a in view.agvs]
    commits = [a.load + sum(s.kind == "pick" for s in a.stops) for a in view.agvs]
    self.rows.append({
      "now": now, "round": bool(round), "pending": len(view.pending),
      "stops": sum(sizes), "max_stops": max(sizes, default=0),
      "full_agvs": sum(c >= MAX_COMMITTED for c in commits),
      "evals": evals, "ms": ms, "delay": delay,
    })


class ExpertLog:
  """Imitation-learning samples: the state at each full replanning round and the
  AGV the dispatcher gave each unpicked order."""

  def __init__(self) -> None:
    self.samples: list[dict] = []

  def decision(self, now, view, plan, pairs, evals, ms, delay, round) -> None:
    if not round:
      return
    assign = {oid: a for oid, a in pairs}
    if plan is not None:
      for a, lst in plan.items():
        for s in lst:
          if s.kind == "pick":
            assign[s.order_id] = a
    held = {s.order_id for a in view.agvs for s in a.stops}
    self.samples.append({
      "now": now,
      "agvs": [
        {"id": a.id, "cell": a.cell, "home": a.home, "load": a.load,
         "stops": [(s.order_id, s.kind, s.cell) for s in a.stops]}
        for a in view.agvs
      ],
      "pending": [_order(o) for o in view.pending],
      "held": [_order(view.orders[i]) for i in sorted(held) if i in view.orders],
      "assign": assign,
    })


class Trace:
  """Per-tick snapshots between `start` and `end` (inclusive), for videos."""

  def __init__(self, start: int = 0, end: int = 10**9) -> None:
    self.start, self.end = start, end
    self.frames: list[dict] = []
    self.on_time = 0
    self.late = 0
    self._seen: set[int] = set()

  def tick(self, now, cells, stops, load, pending, done, orders, agv_of, blocked=(),
           serving=()) -> None:
    for oid, t in done.items():
      if oid not in self._seen:
        self._seen.add(oid)
        if t <= orders[oid].deadline:
          self.on_time += 1
        else:
          self.late += 1
    if not self.start <= now <= self.end:
      return
    self.frames.append({
      "now": now,
      "pos": list(cells),
      "load": list(load),
      "stops": [[(s.order_id, s.kind, s.cell) for s in lst] for lst in stops],
      "pending": [(o.id, o.pickup, o.priority, o.deadline) for o in pending.values()],
      "blocked": list(blocked),
      "serving": list(serving),
      "on_time": self.on_time,
      "late": self.late,
    })
