"""Non-learned baselines and the LinUCB port. All share insertion and traffic."""

from __future__ import annotations

import random

import numpy as np
from scipy.optimize import linear_sum_assignment

from factory_dispatch.insertion import Stop, best_insertion, evaluate, stop_times
from factory_dispatch.orders import Order, generate_orders
from factory_dispatch.sim import AgvView, Dispatcher, Simulation, SimView
from factory_layout import FactoryLayout


def _insert(view: SimView, agv: AgvView, order: Order):
  return best_insertion(
    agv.cell, agv.stops, agv.load, order, view.now, view.index, view.q, view.orders,
    rules=view.rules,
  )


def _apply(agv: AgvView, ins) -> None:
  """Keep the view current so later orders in one call see earlier choices."""
  agv.stops = list(ins.stops)


class RandomDispatcher(Dispatcher):
  def __init__(self, seed: int = 0, defer: float = 0.0) -> None:
    """defer: chance of leaving each pending order unassigned at a decision."""
    self._rng = random.Random(seed)
    self.defer = defer

  def decide(self, view):
    out = []
    for o in view.pending:
      if self.defer and self._rng.random() < self.defer:
        continue
      options = [a for a in view.agvs if _insert(view, a, o) is not None]
      if options:
        a = self._rng.choice(options)
        _apply(a, _insert(view, a, o))
        out.append((o.id, a.id))
    return out


class GreedyDispatcher(Dispatcher):
  """Earliest order first, to the AGV with the cheapest insertion."""

  def decide(self, view):
    out = []
    for o in sorted(view.pending, key=lambda x: (x.arrival, x.id)):
      best = None
      for a in view.agvs:
        ins = _insert(view, a, o)
        if ins is not None and (best is None or ins.cost < best[1].cost):
          best = (a, ins)
      if best is not None:
        _apply(*best)
        out.append((o.id, best[0].id))
    return out


class NearestDispatcher(Dispatcher):
  """Repeatedly take the cheapest (order, AGV) pair anywhere, ignoring age."""

  def decide(self, view):
    out = []
    left = list(view.pending)
    while left:
      best = None
      for o in left:
        for a in view.agvs:
          ins = _insert(view, a, o)
          if ins is not None and (best is None or ins.cost < best[2].cost):
            best = (o, a, ins)
      if best is None:
        break
      o, a, ins = best
      _apply(a, ins)
      left.remove(o)
      out.append((o.id, a.id))
    return out


class ReserveNearest(Dispatcher):
  """Nearest that keeps room for urgent orders: an AGV takes a yellow or green
  order only while it holds fewer than `k` orders; red orders may fill it up to
  the usual limit. k = MAX_COMMITTED is plain Nearest. A fair, simple answer to
  "do not fill every AGV at the shift start" (problem statement 2026-11-08)."""

  def __init__(self, k: int = 2) -> None:
    self.k = k

  def decide(self, view):
    held = {a.id: len({s.order_id for s in a.stops}) for a in view.agvs}
    out = []
    left = list(view.pending)
    while left:
      best = None
      for o in left:
        for a in view.agvs:
          if o.priority != 1 and held[a.id] >= self.k:
            continue
          ins = _insert(view, a, o)
          if ins is not None and (best is None or ins.cost < best[2].cost):
            best = (o, a, ins)
      if best is None:
        break
      o, a, ins = best
      _apply(a, ins)
      held[a.id] += 1
      left.remove(o)
      out.append((o.id, a.id))
    return out


class RollingHungarian(Dispatcher):
  """Every period: optimal one-order-per-AGV matching on insertion cost."""

  def __init__(self, period: int = 30) -> None:
    self.period = period

  def decide(self, view):
    if view.now % self.period or not view.pending:
      return []
    orders = sorted(view.pending, key=lambda o: (o.deadline, o.id))
    big = 1e12
    cost = np.full((len(orders), len(view.agvs)), big)
    for i, o in enumerate(orders):
      for j, a in enumerate(view.agvs):
        ins = _insert(view, a, o)
        if ins is not None:
          cost[i, j] = ins.cost
    rows, cols = linear_sum_assignment(cost)
    return [
      (orders[r].id, view.agvs[c].id) for r, c in zip(rows, cols) if cost[r, c] < big
    ]


def _features(agv: AgvView, order: Order, now: int, h: float, w: float) -> np.ndarray:
  """The source's get_feature terms, scaled so they stay near [-1, 1]."""
  ar, ac = agv.cell[0] / h, agv.cell[1] / w
  pr, pc = order.pickup[0] / h, order.pickup[1] / w
  dr, dc = order.dropoff[0] / h, order.dropoff[1] / w
  start = order.arrival / 9600
  end = order.deadline / 9600
  n = len(agv.stops) / 12
  return np.array([
    1.0, ac, ar, dc, dr, ac * pc, ar * pc, pc, pr, start, end, agv.load / 6, n,
    ac**2, ar**2, ac * ar, dc**2, dr**2, pc**2, pr**2, dc * dr, pc * pr,
  ])


class LinUcbDispatcher(Dispatcher):
  """LinUCB with one arm per AGV (Li et al. 2010), ported from model/bandit.py.

  Reward is 1 if the order is delivered on time, 0 otherwise. The source's reward
  was a hand-tuned distance score; this one is the metric the paper reports.
  """

  def __init__(
    self, seed: int, num_agvs: int, dim: int = 22, alpha: float = 0.01,
    size: tuple[int, int] = (42, 76),
  ) -> None:
    del seed  # Deterministic: kept so every dispatcher is built the same way.
    self.alpha = alpha
    self.A = np.stack([np.eye(dim) for _ in range(num_agvs)])
    self.b = np.zeros((num_agvs, dim))
    self.size = size
    self.learning = True
    self._context: dict[int, tuple[int, np.ndarray]] = {}

  def freeze(self) -> None:
    self.learning = False
    self._context.clear()

  def decide(self, view):
    out = []
    h, w = self.size
    inv = np.linalg.inv(self.A)
    theta = np.einsum("aij,aj->ai", inv, self.b)
    for o in sorted(view.pending, key=lambda x: (x.arrival, x.id)):
      best = None
      for a in view.agvs:
        ins = _insert(view, a, o)
        if ins is None:
          continue
        x = _features(a, o, view.now, h, w)
        score = theta[a.id] @ x
        if self.learning:
          score += self.alpha * np.sqrt(x @ inv[a.id] @ x)
        if best is None or score > best[0]:
          best = (score, a, ins, x)
      if best is not None:
        _, a, ins, x = best
        _apply(a, ins)
        out.append((o.id, a.id))
        if self.learning:
          self._context[o.id] = (a.id, x)
    return out

  def on_complete(self, order, agv, finished):
    ctx = self._context.pop(order.id, None)
    if ctx is None or not self.learning:
      return
    arm, x = ctx
    self.A[arm] += np.outer(x, x)
    self.b[arm] += float(finished <= order.deadline) * x


def train_linucb(
  layout: FactoryLayout, seeds: list[int], horizon: int = 9600, load: float = 1.0
) -> LinUcbDispatcher:
  disp = LinUcbDispatcher(
    0, len(layout.stores), size=(layout.height, layout.width)
  )
  for seed in seeds:
    orders = generate_orders(layout, seed, load=load, horizon=horizon)
    Simulation(layout, orders, disp, horizon=horizon).run()
  disp.freeze()
  return disp


class RollingAlns(Dispatcher):
  """Rolling-horizon large neighbourhood search over the orders not yet assigned.

  An order given to an AGV is carried by that AGV (spec 4.1), so each round only
  searches over how to place the pending orders (and look-ahead ones). Orders
  already held keep their AGV and their place in its stop list.
  """

  def __init__(
    self, period: int = 60, iterations: int = 200, seed: int = 0, destroy: int = 4,
    commit: str = "all", horizon: int = 120,
  ) -> None:
    """commit "all": every planned order is given to its AGV at once. "soon"
    (delayed commitment): plan every pending order, but give an order to its AGV
    only when the AGV would reach its pickup within `horizon` seconds or it is
    that AGV's next destination; the rest stay pending and are planned again."""
    if commit not in ("all", "soon"):
      raise ValueError(commit)
    self.period = period
    self.iterations = iterations
    self.destroy = destroy
    self.commit = commit
    self.horizon = horizon
    self._rng = random.Random(seed)

  def decide(self, view):
    return []

  def _cost(self, view, plan) -> tuple[float, int]:
    """Weighted lateness then travel of every AGV's stop list, free-flow speed."""
    late = 0.0
    travel = 0
    for a, stops in zip(view.agvs, plan):
      got = evaluate(a.cell, stops, a.load, view.q, view.now, view.index, view.orders,
                     view.rules)
      if got is None:
        return float("inf"), 0
      travel += got[0]
      late += got[1] + view.rules.lam * got[2]
    return late, travel

  def _repair(self, view, plan, orders, owner=None) -> list[Order]:
    """Cheapest pair first, as NearestDispatcher does. Returns orders that fit nowhere.

    Deadline-first repair collapses under overload: it chases orders that are
    already nearly lost, and the fleet spends its time on long trips.
    """
    left = list(orders)
    while left:
      best = None
      for o in left:
        for i, a in enumerate(view.agvs):
          if owner and owner.get(o.id, i) != i:
            continue  # A held order goes back to its own AGV only.
          ins = best_insertion(
            a.cell, plan[i], a.load, o, view.now, view.index, view.q, view.orders,
            rules=view.rules,
          )
          if ins is not None and (best is None or ins.cost < best[2].cost):
            best = (o, i, ins)
      if best is None:
        break
      o, i, ins = best
      plan[i] = list(ins.stops)
      left.remove(o)
    return left

  def _unplaced(self, view, plan) -> list[Order]:
    """Pending orders, plus look-ahead orders, that no stop list holds yet."""
    held = {s.order_id for lst in plan for s in lst}
    return [o for o in list(view.pending) + view.future if o.id not in held]

  def replan(self, view):
    if view.now % self.period:
      # Between rounds, new orders still get a greedy placement so none idle.
      if not view.pending:
        return None
      plan = [list(a.stops) for a in view.agvs]
      self._repair(view, plan, view.pending)
      return self._committed(view, plan)

    plan = [list(a.stops) for a in view.agvs]
    held = {s.order_id for lst in plan for s in lst}
    # v2: an AGV may re-sequence its own unpicked orders, never hand them over.
    owner = {
      s.order_id: i for i, lst in enumerate(plan) for s in lst if s.kind == "pick"
    } if view.rules.v2 else {}
    self._repair(view, plan, self._unplaced(view, plan))
    best, best_cost = plan, self._cost(view, plan)
    for _ in range(self.iterations):
      movable = [
        s.order_id for lst in best for s in lst
        if s.kind == "pick" and (s.order_id not in held or s.order_id in owner)
      ]
      if not movable:
        break
      trial = [list(x) for x in best]
      removed = self._rng.sample(movable, min(self.destroy, len(movable)))
      gone = set(removed)
      trial = [[s for s in lst if s.order_id not in gone] for lst in trial]
      left = self._repair(view, trial, [view.orders[i] for i in removed], owner)
      if left:
        continue
      cost = self._cost(view, trial)
      if cost < best_cost:
        best, best_cost = trial, cost
    return self._committed(view, best)

  def _committed(self, view, plan) -> dict[int, list[Stop]]:
    """Drop, under delayed commitment, the new orders not due soon."""
    if self.commit == "all":
      return dict(enumerate(plan))
    held = {s.order_id for a in view.agvs for s in a.stops}
    out = {}
    for i, (a, lst) in enumerate(zip(view.agvs, plan)):
      times = stop_times(a.cell, lst, view.now, view.index, view.orders, view.rules)
      keep_ids = set()
      first_new = next((s.order_id for s in lst if s.order_id not in held), None)
      for s, t in zip(lst, times):
        if s.kind != "pick" or s.order_id in held:
          continue
        if t <= view.now + self.horizon or (s.order_id == first_new and not a.stops):
          keep_ids.add(s.order_id)
      out[i] = [s for s in lst if s.order_id in held or s.order_id in keep_ids]
    return out


class LookaheadAlns(RollingAlns):
  """Reference, not a deployable method: RollingAlns that also plans the orders
  arriving within `window` seconds, then commits only to orders that exist.

  Knowing the future can change today's choices (keep room on an AGV for an
  urgent order due soon) without parking AGVs to wait for orders.

  The gap between this and the online methods estimates how much knowing the
  future is worth. It is a heuristic, not an optimum or a bound.
  """

  def __init__(self, window: int, period: int = 60, iterations: int = 200,
               seed: int = 0, destroy: int = 4) -> None:
    super().__init__(period, iterations, seed, destroy)
    self.lookahead = window

  def replan(self, view):
    plan = super().replan(view)
    if plan is None or not view.future:
      return plan
    future = {o.id for o in view.future}
    return {
      a: [s for s in stops if s.order_id not in future] for a, stops in plan.items()
    }
