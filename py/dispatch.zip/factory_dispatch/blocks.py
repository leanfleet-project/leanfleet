"""Dynamic road blocks (author's spec 4b): a stalled vehicle, a forklift, people or
goods left in the aisle close one road edge for a while.

Dispatchers learn that an edge is closed when it closes, never when it reopens.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass

from factory_layout import FactoryLayout, build_road_graph
from factory_layout.layout import Cell

MEDIAN_SEC = 180
SIGMA = 0.8
MAX_SEC = 1800


@dataclass(frozen=True)
class Block:
  cells: tuple[Cell, ...]
  start: int
  end: int


def block_schedule(
  layout: FactoryLayout, seed: int, rate_per_hour: float = 4.0, shift: int = 9600
) -> list[Block]:
  """Poisson block starts over the shift, each on the interior cells of one road
  edge (junction cells stay open), lognormal durations capped at MAX_SEC."""
  rng = random.Random(f"blocks-{seed}")
  edges = [tuple(e.cells[1:-1]) for e in build_road_graph(layout).edges if len(e.cells) > 2]
  out: list[Block] = []
  t = 0.0
  while rate_per_hour > 0:
    t += rng.expovariate(rate_per_hour / 3600)
    if t >= shift:
      break
    dur = min(MAX_SEC, max(1, round(rng.lognormvariate(math.log(MEDIAN_SEC), SIGMA))))
    out.append(Block(rng.choice(edges), int(t), int(t) + dur))
  return out
