"""Online orders: an order appears somewhere; a robot takes it onward by plan.

Flow plan: a station on line N sends to a station on line N+1 (wrapping) or back
to store N; store N sends to a station on line N. Rhythm and deadlines follow the
source generator, so load 1.0 means the source's order rate.

Each order has a priority (1 urgent: a line may stop, 2 normal, 3 low: back to
store) and a size in tenths of an AGV's capacity.
"""

from __future__ import annotations

import dataclasses
import random
import re
from dataclasses import dataclass

from factory_layout import FactoryLayout
from factory_layout.layout import Cell

_FREQ = {"1": 0.70, "2": 0.40, "3": 0.60}
DEFAULT_KEEP = 0.6
"""Keep rate for layouts outside the source set (generated layouts)."""
PRIORITY_WEIGHT = {1: 10.0, 2: 1.0, 3: 0.2}
CAPACITY_TENTHS = 10
SLOT_CAPACITY = 6
"""v2: trays per AGV; an order's `size` counts trays."""
PLANNED_SHARE = 0.7
SIZES = (1, 2, 3, 5)
SIZE_PROBS = (0.35, 0.30, 0.20, 0.15)
P_URGENT_FROM_STORE = 0.3
P_URGENT_TO_NEXT_LINE = 0.1
URGENT_SLACK = 600
TAKT_SPREAD = (0.8, 1.2)
"""Each source's period is its mean renewal interval in the random pattern times a
factor drawn from this range, so both patterns carry the same load."""
TAKT_JITTER = 0.1
FEASIBLE_MARGIN = 1.5
"""v2: every deadline leaves at least this times the time an idle AGV at the nearest
warehouse needs (drive to the pickup, carry to the drop, both dwells). Before
2026-11-08 urgent slack was 2 x straight-line distance, and on long corridors some
red orders were late even for a free AGV."""


@dataclass(frozen=True)
class Order:
  id: int
  pickup: Cell
  dropoff: Cell
  arrival: int
  deadline: int
  priority: int = 2
  size: int = 1
  """Workload: tenths of capacity in v1, trays (of SLOT_CAPACITY) in v2."""
  planned: bool = False
  """v2: part of the shift plan, visible to dispatchers from `known_at`."""
  known_at: int = -1
  """When dispatchers first see the order; -1 means at arrival."""
  planned_time: int = -1
  """v2 planned orders: the time in the plan; `arrival` is when it really appears."""


def _line(label: str) -> int:
  return int(re.match(r"\d+", label).group())


def _manhattan(a: Cell, b: Cell) -> int:
  return abs(a[0] - b[0]) + abs(a[1] - b[1])


def generate_orders(
  layout: FactoryLayout,
  seed: int,
  load: float = 1.0,
  horizon: int = 9600,
  p_next: float = 0.7,
  pattern: str = "random",
  p_keep: float | None = None,
) -> list[Order]:
  """pattern "random" keeps the source's renewal process; "takt" gives each
  source a fixed period with small jitter, as a production line would."""
  if pattern not in ("random", "takt"):
    raise ValueError(pattern)
  rng = random.Random(seed)
  # Separate stream so adding attributes leaves the random pattern unchanged.
  attr = random.Random(f"attrs-{seed}")
  keep = _FREQ.get(layout.name[3:4], DEFAULT_KEEP) if p_keep is None else p_keep
  stations: dict[int, list[Cell]] = {}
  for label, cells in sorted(layout.stations.items()):
    stations.setdefault(_line(label), []).extend(cells)
  stores = {_line(label): cells[0] for label, cells in layout.stores.items()}
  lines = sorted(stations)

  def next_line(n: int) -> int:
    return lines[(lines.index(n) + 1) % len(lines)]

  sources: list[tuple[Cell, int, bool]] = [
    (c, n, False) for n in lines for c in stations[n]
  ] + [(c, n, True) for n, c in sorted(stores.items()) if n in stations]

  def target_of(cell: Cell, line: int, is_store: bool, r: random.Random) -> Cell:
    if is_store:
      return r.choice(stations[line])
    if line in stores and r.random() >= p_next:
      return stores[line]
    return r.choice(stations[next_line(line)])

  def attributes(src_store: bool, target: Cell) -> tuple[int, int]:
    if target in stores.values():
      priority = 3
    else:
      p = P_URGENT_FROM_STORE if src_store else P_URGENT_TO_NEXT_LINE
      priority = 1 if attr.random() < p else 2
    size = attr.choices(SIZES, SIZE_PROBS)[0]
    return priority, size

  def slack_of(d: int, priority: int, r: random.Random) -> int:
    cap = URGENT_SLACK if priority == 1 else 2000
    return r.randint(2 * d, cap) if 2 * d <= cap else 2 * d

  raw = []
  if pattern == "random":
    for cell, line, is_store in sources:
      t = float(rng.randint(0, 10))
      while t < horizon:
        target = target_of(cell, line, is_store, rng)
        d = _manhattan(cell, target)
        if target != cell and rng.randint(0, 100) <= keep * 100:
          slack = slack_of(d, 2, rng)  # Always drawn: keeps the source stream.
          priority, size = attributes(is_store, target)
          if priority == 1:
            slack = slack_of(d, 1, attr)
          raw.append((int(t), cell, target, int(t) + slack, priority, size))
        t += max(1.0, (rng.randint(0, 10) + 2 * d) / load)
  else:
    for cell, line, is_store in sources:
      if is_store:
        targets = stations[line]
      else:
        nxt = stations[next_line(line)]
        targets = nxt if line not in stores else nxt + [stores[line]]
      mean_d = sum(_manhattan(cell, c) for c in targets) / len(targets)
      period = (5 + 2 * mean_d) * rng.uniform(*TAKT_SPREAD) / load
      t = rng.uniform(0, period)
      while t < horizon:
        target = target_of(cell, line, is_store, rng)
        if target != cell and rng.random() < keep:
          d = _manhattan(cell, target)
          priority, size = attributes(is_store, target)
          raw.append(
            (int(t), cell, target, int(t) + slack_of(d, priority, rng), priority, size)
          )
        t += period * rng.uniform(1 - TAKT_JITTER, 1 + TAKT_JITTER)
  raw.sort(key=lambda r: (r[0], r[1], r[2]))
  return [Order(i, p, q, a, e, pr, sz) for i, (a, p, q, e, pr, sz) in enumerate(raw)]


def generate_shift(
  layout: FactoryLayout,
  seed: int,
  load: float = 1.0,
  shift: int = 9600,
  planned_share: float = PLANNED_SHARE,
) -> list[Order]:
  """v2 shift: planned orders (all available from the shift start, deadlines spread
  over the shift by the takt rhythm) plus dynamic ones (random pattern, known on
  arrival). The two are thinned so the total rate equals one pattern's rate."""
  pick = random.Random(f"shift-{seed}")
  raw: list[Order] = []
  for o in generate_orders(layout, seed, load=load, horizon=shift, pattern="takt"):
    if pick.random() < planned_share:
      raw.append(dataclasses.replace(
        o, arrival=0, planned=True, known_at=0, planned_time=o.arrival))
  for o in generate_orders(layout, seed + 7919, load=load, horizon=shift, pattern="random"):
    if pick.random() >= planned_share:
      raw.append(dataclasses.replace(o, known_at=o.arrival))
  raw = _feasible_deadlines(layout, raw)
  raw.sort(key=lambda o: (o.arrival, o.pickup, o.dropoff, o.planned))
  return [dataclasses.replace(o, id=i) for i, o in enumerate(raw)]


def _feasible_deadlines(layout: FactoryLayout, orders: list[Order]) -> list[Order]:
  """Push each deadline to at least FEASIBLE_MARGIN x the idle-AGV service time."""
  import math

  from factory_dispatch.insertion import dwell
  from factory_dispatch.traffic import UNREACHABLE, RoadIndex
  from factory_layout import build_road_graph

  idx = RoadIndex(build_road_graph(layout))
  stores = [idx.ids[c[0]] for c in layout.stores.values()]
  tables: dict[Cell, list[int]] = {}
  out = []
  for o in orders:
    if o.pickup not in tables:
      tables[o.pickup] = idx.dist_to(idx.ids[o.pickup])
    t = tables[o.pickup]
    legs = min(t[s] for s in stores) + t[idx.ids[o.dropoff]]
    if legs >= UNREACHABLE:
      out.append(o)
      continue
    need = math.ceil(FEASIBLE_MARGIN * (legs + 2 * dwell(o)))
    out.append(dataclasses.replace(o, deadline=max(o.deadline, o.arrival + need)))
  return out
