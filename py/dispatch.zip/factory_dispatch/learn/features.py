"""Observation for the learned dispatcher (spec section 5).

A heterogeneous graph built at every decision:
- road nodes and directed road edges of the contracted graph, with blocks and the
  planned occupancy of each direction in the next 0-30 / 30-60 / 60-120 s;
- AGV tokens, order tokens (pending orders plus planned orders due within
  LOOKAHEAD), and (order, AGV) pair features from cheapest insertion for the
  K_NEAREST AGVs nearest each pickup.

No absolute coordinates and no ids: the same model runs on any layout and fleet.
Times use `tt(x) = sign(x) * log1p(|x| / 60)`, so seconds and hours both stay small.
Planned orders that have not appeared are described by their plan, never by their
real (jittered) arrival, which a dispatcher cannot know.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

from factory_dispatch.insertion import (
  MAX_COMMITTED,
  best_insertion,
  dwell,
  stop_times,
)
from factory_dispatch.orders import PRIORITY_WEIGHT, SLOT_CAPACITY, Order
from factory_dispatch.sim import AgvView, SimView
from factory_dispatch.traffic import UNREACHABLE, RoadIndex

LOOKAHEAD = 900
K_NEAREST = 8
WINDOWS = (30, 60, 120)
ON_ROUTE_CELLS = 4
NODE_DIM, EDGE_DIM, AGV_DIM, ORDER_DIM, PAIR_DIM, GLOB_DIM = 6, 9, 10, 9, 8, 6


def tt(x: float) -> float:
  return math.copysign(math.log1p(abs(x) / 60.0), x)


class GraphCache:
  """Static structure of one layout's contracted road graph."""

  def __init__(self, index: RoadIndex) -> None:
    self.index = index
    self.graph = g = index.graph
    self.node_id = {c: i for i, c in enumerate(g.nodes)}
    n, e = len(g.nodes), len(g.edges)
    self.n_nodes, self.n_edges = n, e
    deg = np.zeros(n)
    for ed in g.edges:
      deg[ed.u] += 1
      deg[ed.v] += 1
    self.node_type = np.zeros((n, 4), np.float32)  # junction, station, store, dead end
    self.node_type[:, 0] = deg >= 3
    self.node_type[:, 3] = deg <= 1
    self.edge_of_cell: dict[int, int] = {}
    self.anchor: dict[int, tuple[int, int, float]] = {}
    """cell id -> (node a, node b, weight of b): where a token sits on the graph."""
    self.step: dict[tuple[int, int], tuple[int, int]] = {}
    """(cell id, next cell id) -> (edge, direction 0 = u->v, 1 = v->u)."""
    ids = index.ids
    for k, ed in enumerate(g.edges):
      cells = [ids[c] for c in ed.cells]
      last = len(cells) - 1
      for j, c in enumerate(cells):
        if 0 < j < last:
          self.edge_of_cell[c] = k
          self.anchor[c] = (ed.u, ed.v, j / last)
      for a, b in zip(cells, cells[1:]):
        self.step[(a, b)] = (k, 0)
        self.step[(b, a)] = (k, 1)
    for c, i in self.node_id.items():
      self.anchor[ids[c]] = (i, i, 0.0)
    src = [ed.u for ed in g.edges] + [ed.v for ed in g.edges]
    dst = [ed.v for ed in g.edges] + [ed.u for ed in g.edges]
    self.edge_index = np.array([src, dst], np.int64).reshape(2, 2 * e)
    self.edge_len = np.array([ed.length for ed in g.edges], np.float32)
    layout = g.layout
    for col, group in ((1, layout.stations), (2, layout.stores)):
      for cells in group.values():
        for c in cells:
          if c in self.node_id:
            self.node_type[self.node_id[c], col] = 1

  def nearest_node(self, cell_id: int) -> int:
    a, b, w = self.anchor[cell_id]
    return b if w > 0.5 else a


@dataclass
class Encoded:
  node_x: np.ndarray
  edge_index: np.ndarray
  edge_x: np.ndarray
  agv_x: np.ndarray
  agv_node: np.ndarray
  agv_w: np.ndarray
  order_x: np.ndarray
  order_node: np.ndarray
  pair_index: np.ndarray
  pair_x: np.ndarray
  pair_ok: np.ndarray
  glob: np.ndarray
  order_ids: list[int]
  agv_ids: list[int]
  pending_rows: list[int] = field(default_factory=list)
  assigned: set[int] = field(default_factory=set)
  """Order rows given to an AGV during this decision."""


def _view_order(o: Order, now: int) -> tuple[int, int]:
  """(arrival, deadline) as the dispatcher may know them."""
  if o.planned and o.arrival > now and o.planned_time >= 0:
    return o.planned_time, o.deadline - o.arrival + o.planned_time
  return o.arrival, o.deadline


def _route(view: SimView, agv: AgvView, cache: GraphCache):
  """Walk the AGV's stop list at free-flow speed. Returns (end time, drop finish
  times per order, occupancy list of (edge, dir, t)) with occupancy only up to the
  last window."""
  index = view.index
  now = view.now
  here = index.ids[agv.cell]
  t = max(now, agv.busy_until)
  serving_head = agv.busy_until > now
  finish: dict[int, int] = {}
  occ: list[tuple[int, int, int]] = []
  horizon = now + WINDOWS[-1]
  for j, s in enumerate(agv.stops):
    target = index.ids[s.cell]
    table = index.dist_to(target)
    if table[here] >= UNREACHABLE:
      return UNREACHABLE, finish, occ
    while here != target:
      nxt = next(nb for nb in index.nbrs[here] if table[nb] == table[here] - 1)
      if t < horizon:
        st = cache.step.get((here, nxt))
        if st is not None:
          occ.append((st[0], st[1], t - now))
      here = nxt
      t += 1
    o = view.orders.get(s.order_id)
    if s.kind == "via" or o is None:
      continue
    if s.kind == "pick":
      t = max(t, o.arrival)
    if not (j == 0 and serving_head):
      t += dwell(o)
    if s.kind == "drop":
      finish[s.order_id] = t
  return t, finish, occ


def _lateness(view: SimView, agv: AgvView, stops) -> dict[int, float]:
  times = stop_times(agv.cell, stops, view.now, view.index, view.orders, view.rules)
  out = {}
  for s, t in zip(stops, times):
    if s.kind == "drop" and s.order_id in view.orders:
      o = view.orders[s.order_id]
      out[s.order_id] = max(0, t + dwell(o) - o.deadline)
  return out


def _trays(view: SimView, agv: AgvView) -> tuple[int, int]:
  picks = {s.order_id for s in agv.stops if s.kind == "pick"}
  size = lambda i: view.orders[i].size if i in view.orders else 0  # noqa: E731
  onboard = sum(size(s.order_id) for s in agv.stops if s.kind == "drop" and s.order_id not in picks)
  return onboard, sum(size(i) for i in picks)


def _agv_row(view: SimView, agv: AgvView, cache: GraphCache):
  end, finish, occ = _route(view, agv, cache)
  onboard, reserved = _trays(view, agv)
  held = {s.order_id for s in agv.stops if s.kind != "via" and s.order_id in view.orders}
  colors = [sum(view.orders[i].priority == p for i in held) / MAX_COMMITTED for p in (1, 2, 3)]
  slack = min((view.orders[i].deadline - t for i, t in finish.items()), default=3600)
  x = [
    onboard / SLOT_CAPACITY, reserved / SLOT_CAPACITY,
    tt(max(0, agv.busy_until - view.now)),
    tt(min(end, view.now + 36000) - view.now),
    *colors, tt(slack), len(agv.stops) / (2 * MAX_COMMITTED), float(not agv.stops),
  ]
  return x, occ, onboard + reserved


def _pair_row(view: SimView, agv: AgvView, o: Order, base_late: dict[int, float]):
  ins = best_insertion(agv.cell, agv.stops, agv.load, o, view.now, view.index, view.q,
                       view.orders, rules=view.rules)
  if ins is None:
    return [0.0] * PAIR_DIM, False
  info = dict(view.orders)
  info[o.id] = o
  times = stop_times(agv.cell, ins.stops, view.now, view.index, info, view.rules)
  eta = next(t for s, t in zip(ins.stops, times) if s.order_id == o.id and s.kind == "pick")
  drop_t = next(t for s, t in zip(ins.stops, times) if s.order_id == o.id and s.kind == "drop")
  new_late = _lateness(view, agv, ins.stops)
  worse = sum(new_late.get(i, 0) > base_late.get(i, 0) for i in base_late)
  picks = {s.order_id for s in agv.stops if s.kind == "pick"}
  onboard = sum(view.orders[s.order_id].size for s in agv.stops
                if s.kind == "drop" and s.order_id not in picks and s.order_id in view.orders)
  peak = onboard
  for s in ins.stops:
    size = info[s.order_id].size if s.order_id in info else 0
    onboard += size if s.kind == "pick" else -size if s.kind == "drop" else 0
    peak = max(peak, onboard)
  return [
    tt(ins.added_travel), tt(ins.added_tardiness / PRIORITY_WEIGHT[o.priority]),
    tt(ins.added_flow), tt(eta - view.now), tt(o.deadline - drop_t - dwell(o)),
    worse / MAX_COMMITTED, float(ins.added_travel <= ON_ROUTE_CELLS), peak / SLOT_CAPACITY,
  ], True


def encode(view: SimView, lam: float, cache: GraphCache) -> Encoded:
  index = view.index
  now = view.now
  agvs = view.agvs
  n_a = len(agvs)

  # Orders: pending first (assignable), then planned ones due within LOOKAHEAD.
  pending = sorted(view.pending, key=lambda o: (o.arrival, o.id))
  planned = sorted(
    (o for o in view.planned if _view_order(o, now)[0] <= now + LOOKAHEAD
     and o.id not in {p.id for p in pending}),
    key=lambda o: (_view_order(o, now)[0], o.id),
  )
  orders = pending + planned
  order_x = np.zeros((len(orders), ORDER_DIM), np.float32)
  order_node = np.zeros((len(orders), 2), np.int64)
  pickups_here = np.zeros(cache.n_nodes, np.float32)
  for r, o in enumerate(orders):
    arrival, deadline = _view_order(o, now)
    is_planned = r >= len(pending)
    p, d = index.ids[o.pickup], index.ids[o.dropoff]
    service = index.dist_to(d)[p]
    service = service if service < UNREACHABLE else 3600
    order_x[r] = [
      o.priority == 1, o.priority == 2, o.priority == 3, o.size / SLOT_CAPACITY,
      tt(deadline - now), tt(service + 2 * dwell(o)), tt(max(0, now - arrival)),
      tt(max(0, arrival - now)), float(is_planned),
    ]
    order_node[r] = (cache.nearest_node(p), cache.nearest_node(d))
    pickups_here[order_node[r, 0]] += 1

  # AGVs and planned occupancy.
  agv_x = np.zeros((n_a, AGV_DIM), np.float32)
  agv_node = np.zeros((n_a, 2), np.int64)
  agv_w = np.zeros((n_a, 2), np.float32)
  occ = np.zeros((cache.n_edges, 2, len(WINDOWS)), np.float32)
  serving_here = np.zeros(cache.n_nodes, np.float32)
  committed = 0
  for r, a in enumerate(agvs):
    x, path, used = _agv_row(view, a, cache)
    agv_x[r] = x
    committed += used
    cid = index.ids[a.cell]
    u, v, w = cache.anchor[cid]
    agv_node[r] = (u, v)
    agv_w[r] = (1 - w, w)
    if a.busy_until > now:
      serving_here[cache.nearest_node(cid)] += 1
    for e, d, dt in path:
      k = next(i for i, lim in enumerate(WINDOWS) if dt < lim)
      occ[e, d, k] += 1
  occ /= np.maximum(cache.edge_len, 1)[:, None, None]

  # Edges, both directions.
  e = cache.n_edges
  blocked_edges = np.zeros(e, np.float32)
  since = np.zeros(e, np.float32)
  for c, start in view.blocked_since.items():
    k = cache.edge_of_cell.get(index.ids.get(c, -1))
    if k is not None:
      blocked_edges[k] = 1
      since[k] = max(since[k], tt(now - start))
  edge_x = np.zeros((2 * e, EDGE_DIM), np.float32)
  for half, (fwd, back) in enumerate(((0, 1), (1, 0))):
    rows = slice(half * e, (half + 1) * e)
    edge_x[rows, 0] = cache.edge_len / 60.0
    edge_x[rows, 1] = blocked_edges
    edge_x[rows, 2] = since
    edge_x[rows, 3:6] = occ[:, fwd]
    edge_x[rows, 6:9] = occ[:, back]

  node_x = np.concatenate(
    [cache.node_type, pickups_here[:, None], serving_here[:, None]], 1
  ).astype(np.float32)

  # Pairs: each pending order with its K_NEAREST AGVs by distance to the pickup.
  base_late = [_lateness(view, a, a.stops) for a in agvs]
  pair_index, pair_x, pair_ok = [], [], []
  for r, o in enumerate(pending):
    table = index.dist_to(index.ids[o.pickup])
    near = sorted(range(n_a), key=lambda i: (table[index.ids[agvs[i].cell]], i))[:K_NEAREST]
    for i in near:
      x, ok = _pair_row(view, agvs[i], o, base_late[i])
      pair_index.append((r, i))
      pair_x.append(x)
      pair_ok.append(ok)

  arrived = sum(1 for o in view.orders.values() if now - 600 <= o.arrival <= now)
  glob = np.array([
    math.log1p(lam), len(pending) / n_a,
    max(0.0, 1 - committed / (SLOT_CAPACITY * n_a)),
    sum(o.priority == 1 for o in pending) / n_a, arrived / n_a,
    float(blocked_edges.mean()) if e else 0.0,
  ], np.float32)
  return Encoded(
    node_x, cache.edge_index, edge_x, agv_x, agv_node, agv_w, order_x, order_node,
    np.array(pair_index, np.int64).reshape(-1, 2),
    np.array(pair_x, np.float32).reshape(-1, PAIR_DIM),
    np.array(pair_ok, bool), glob, [o.id for o in orders], [a.id for a in agvs],
    list(range(len(pending))),
  )


def update_agv(enc: Encoded, view: SimView, row: int, cache: GraphCache) -> None:
  """After the AGV in `row` got a new order: refresh its token and its pairs."""
  agv = view.agvs[row]
  x, _, _ = _agv_row(view, agv, cache)
  enc.agv_x[row] = x
  base = _lateness(view, agv, agv.stops)
  pending = {o.id: o for o in view.pending}
  for k, (r, i) in enumerate(enc.pair_index):
    if i == row and r not in enc.assigned:
      o = pending.get(enc.order_ids[r])
      if o is None:
        enc.pair_ok[k] = False
        continue
      px, ok = _pair_row(view, agv, o, base)
      enc.pair_x[k] = px
      enc.pair_ok[k] = ok


def mark_assigned(enc: Encoded, order_row: int) -> None:
  enc.assigned.add(order_row)
  enc.pair_ok[enc.pair_index[:, 0] == order_row] = False
