"""The student without torch: a numpy forward pass and dispatcher for the project page.

Pyodide has numpy but not torch, so the page runs the trained weights (exported to .npz
by `learn.export.export_npz`) through this re-implementation of `DispatchPolicy` for one
state, and `PageGnnDispatcher` mirrors `GnnDispatcher.decide` (marginal decoding, the
overdue rule, charged forward time). Tests check both against the torch versions.
"""
from __future__ import annotations

import math

import numpy as np

from factory_dispatch.insertion import best_insertion
from factory_dispatch.learn.features import GraphCache, encode, mark_assigned, update_agv
from factory_dispatch.sim import Dispatcher, SimView

REVIEW_PERIOD = 30
"""As learn.dispatcher.REVIEW_PERIOD (that module imports torch)."""
FORWARD_BASE, FORWARD_PER_NODE, FORWARD_PER_TOKEN = 5e-4, 1.2e-5, 8e-6
"""As learn.dispatcher: seconds charged per forward pass."""
LN_EPS = 1e-5


def forward_sec(n_nodes: int, n_tokens: int) -> float:
  return FORWARD_BASE + FORWARD_PER_NODE * n_nodes + FORWARD_PER_TOKEN * n_tokens


class NumpyPolicy:
  """DispatchPolicy.forward for a single encoded state, in float32 numpy."""

  def __init__(self, path) -> None:
    with np.load(path) as z:
      self.w = {k: z[k].astype(np.float32) for k in z.files if not k.startswith("meta.")}
      self.heads = int(z["meta.heads"])
    self.road = sum(1 for k in self.w if k.startswith("road.") and k.endswith(".norm.weight"))
    self.tf = sum(1 for k in self.w if k.startswith("tf.layers.") and k.endswith(".norm1.weight"))

  def _lin(self, p, x):
    return x @ self.w[p + ".weight"].T + self.w[p + ".bias"]

  def _mlp(self, p, x):
    return self._lin(p + ".2", np.maximum(self._lin(p + ".0", x), 0.0))

  def _ln(self, p, x):
    mu = x.mean(-1, keepdims=True)
    var = ((x - mu) ** 2).mean(-1, keepdims=True)
    return (x - mu) / np.sqrt(var + LN_EPS) * self.w[p + ".weight"] + self.w[p + ".bias"]

  def _attn(self, p, x):
    h = x.shape[1]
    d = h // self.heads
    qkv = x @ self.w[p + ".in_proj_weight"].T + self.w[p + ".in_proj_bias"]
    q, k, v = (qkv[:, i * h:(i + 1) * h].reshape(-1, self.heads, d).transpose(1, 0, 2)
               for i in range(3))
    s = q @ k.transpose(0, 2, 1) / np.float32(math.sqrt(d))
    s = np.exp(s - s.max(-1, keepdims=True))
    s = s / s.sum(-1, keepdims=True)
    out = (s @ v).transpose(1, 0, 2).reshape(-1, h)
    return self._lin(p + ".out_proj", out)

  def __call__(self, enc):
    f32 = lambda a: np.asarray(a, np.float32)  # noqa: E731
    x = self._mlp("node_in", f32(enc.node_x))
    e = self._mlp("edge_in", f32(enc.edge_x))
    src, dst = np.asarray(enc.edge_index, np.intp)
    n = x.shape[0]
    for i in range(self.road):
      p = f"road.{i}"
      m = self._mlp(p + ".msg", np.concatenate([x[src], e], 1))
      agg = np.zeros_like(x)
      np.add.at(agg, dst, m)
      deg = np.maximum(np.bincount(dst, minlength=n), 1).astype(np.float32)[:, None]
      x = self._ln(p + ".norm", x + self._mlp(p + ".upd", np.concatenate([x, agg / deg], 1)))
    an, aw = np.asarray(enc.agv_node, np.intp), f32(enc.agv_w)
    agv = self._mlp("agv_in", f32(enc.agv_x)) + self._lin(
      "at_node", x[an[:, 0]] * aw[:, :1] + x[an[:, 1]] * aw[:, 1:])
    on = np.asarray(enc.order_node, np.intp)
    order = (self._mlp("order_in", f32(enc.order_x)) + self._lin("at_pick", x[on[:, 0]])
             + self._lin("at_drop", x[on[:, 1]]))
    glob = self._mlp("glob_in", f32(enc.glob)[None])
    te = self.w["type_emb.weight"]
    tok = np.concatenate([agv + te[0], order + te[1], glob + te[2]], 0)
    for i in range(self.tf):
      p = f"tf.layers.{i}"
      tok = self._ln(p + ".norm1", tok + self._attn(p + ".self_attn", tok))
      ff = self._lin(p + ".linear2", np.maximum(self._lin(p + ".linear1", tok), 0.0))
      tok = self._ln(p + ".norm2", tok + ff)
    na, no = agv.shape[0], order.shape[0]
    agv, order, glob = tok[:na], tok[na:na + no], tok[na + no:]
    pi = np.asarray(enc.pair_index, np.intp)
    if len(pi):
      s = self._mlp("score", np.concatenate(
        [order[pi[:, 0]], agv[pi[:, 1]], self._mlp("pair_in", f32(enc.pair_x))], 1))[:, 0]
      logits = np.where(np.asarray(enc.pair_ok, bool), s, -np.inf).astype(np.float32)
    else:
      logits = np.zeros(0, np.float32)
    pooled = np.concatenate([glob, agv.mean(0, keepdims=True), order.mean(0, keepdims=True)], 1)
    defer = float(self._mlp("defer", pooled)[0, 0])
    return logits, defer


def pick_marginal(logits: np.ndarray, defer: float) -> int:
  """As learn.ppo.pick(mode="marginal"): defer when its softmax share is at least 0.5."""
  scores = np.concatenate([logits, np.array([defer], np.float32)]).astype(np.float32)
  m = scores[np.isfinite(scores)].max()
  ex = np.exp(scores - m)
  if float(ex[-1] / ex.sum()) >= 0.5:
    return len(logits)
  return int(np.argmax(logits))


class PageGnnDispatcher(Dispatcher):
  """GnnDispatcher (decode="marginal", no reserve cap) on a NumpyPolicy."""
  period = REVIEW_PERIOD

  def __init__(self, policy: NumpyPolicy) -> None:
    self.policy = policy
    self.extra_sec = 0.0
    self._cache: tuple[int, GraphCache] | None = None

  def decide(self, view: SimView):
    self.extra_sec = 0.0
    if not view.pending:
      return []
    if self._cache is None or self._cache[0] != id(view.index):
      self._cache = (id(view.index), GraphCache(view.index))
    cache = self._cache[1]
    enc = encode(view, view.rules.lam, cache)
    saved = list(view.pending)
    out = []
    n = 0
    while True:
      logits, defer = self.policy(enc)
      n += 1
      if logits.size == 0:
        break
      k = pick_marginal(logits, defer)
      if k == len(logits) or not np.isfinite(logits[k]):
        break
      r, g = (int(v) for v in enc.pair_index[k])
      agv = view.agvs[g]
      o = view.orders[enc.order_ids[r]]
      ins = best_insertion(agv.cell, agv.stops, agv.load, o, view.now, view.index,
                           view.q, view.orders, rules=view.rules)
      mark_assigned(enc, r)
      if ins is None:
        continue
      agv.stops = list(ins.stops)
      view.pending = [p for p in view.pending if p.id != o.id]
      out.append((o.id, agv.id))
      update_agv(enc, view, g, cache)
    out += self._overdue(view)
    view.pending = saved
    tokens = enc.agv_x.shape[0] + enc.order_x.shape[0]
    self.extra_sec = n * forward_sec(cache.n_nodes, tokens)
    return out

  @staticmethod
  def _overdue(view: SimView) -> list[tuple[int, int]]:
    """As GnnDispatcher._overdue."""
    out = []
    for o in sorted((p for p in view.pending if p.deadline <= view.now),
                    key=lambda p: p.deadline):
      best = None
      for agv in view.agvs:
        ins = best_insertion(agv.cell, agv.stops, agv.load, o, view.now, view.index,
                             view.q, view.orders, rules=view.rules)
        if ins is not None and (best is None or ins.cost < best[0].cost):
          best = (ins, agv)
      if best is not None:
        best[1].stops = list(best[0].stops)
        view.pending = [p for p in view.pending if p.id != o.id]
        out.append((o.id, best[1].id))
    return out
