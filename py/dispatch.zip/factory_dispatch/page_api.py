"""Entry points the project page calls in the browser (Pyodide), kept free of torch.

The same functions run natively in the tests, so the browser build can be checked
against Python (P4b parity check 1). Results are plain JSON values.
"""
from __future__ import annotations

import re

from factory_dispatch.baselines import NearestDispatcher, ReserveNearest
from factory_dispatch.fleet_sizing import demand_instance, with_fleet
from factory_dispatch.sim import Simulation
from factory_layout import generate_layout, load_layout

SEC_PER_EVAL = 3e-6
"""Seconds charged per insertion evaluation, as `scripts/run_latency.SEC_PER_EVAL`."""


def layout_of(spec: str, seed: int):
  """map names, or gLxSxA generated families (as scripts/run_fleet_sizing.layout_of)."""
  m = re.fullmatch(r"g(\d+)x(\d+)x(\d+)", spec)
  return generate_layout(seed, *map(int, m.groups())) if m else load_layout(spec)


def make_dispatcher(name: str, student: str | None = None):
  if name == "student":
    from factory_dispatch.learn.numpy_policy import NumpyPolicy, PageGnnDispatcher
    return PageGnnDispatcher(NumpyPolicy(student))
  if name == "nearest":
    return NearestDispatcher()
  m = re.fullmatch(r"reserve(\d)", name)
  if m:
    return ReserveNearest(int(m.group(1)))
  raise ValueError(f"unknown dispatcher {name!r}")


def run_case(layout: str, seed: int, agvs: int, shift: int = 3600,
             dispatcher: str = "reserve1", student: str | None = None) -> dict:
  """One run on a fleet-sizing instance; summary metrics as JSON values."""
  inst = with_fleet(demand_instance(layout_of(layout, seed), seed, shift=shift), agvs)
  disp = make_dispatcher(dispatcher, student)
  calls = [0]

  class Count:
    def decision(self, **kw) -> None:
      calls[0] += 1

  m = Simulation(inst.layout, inst.orders, disp, rules=inst.rules, shift=inst.shift,
                 homes=inst.homes, blocks=inst.blocks, sec_per_eval=SEC_PER_EVAL,
                 period=getattr(disp, "period", None),
                 recorders=[Count()]).run()
  return dict(layout=layout, seed=seed, agvs=agvs, dispatcher=dispatcher,
              orders=len(inst.orders), J=round(m.objective, 6),
              red_on_time=round(m.on_time_p1, 6), on_time=round(m.on_time_rate, 6),
              unfinished=int(m.unfinished), makespan=int(m.makespan), decisions=calls[0])


def trays_on_board(stops: list, orders: dict) -> list[int]:
  """Priority of each tray in use: orders with a drop still due but no pick (as the 3D
  replay, scripts/play_gnn.py)."""
  from factory_dispatch.orders import SLOT_CAPACITY
  picks = {s[0] for s in stops if s[1] == "pick"}
  out: list[int] = []
  for oid, kind, _ in stops:
    if kind == "drop" and oid not in picks:
      out += [orders[oid].priority] * orders[oid].size
  return out[:SLOT_CAPACITY]


class TickLog:
  """Per-tick AGV cells and trays, for the page's 3D replay (as Trace frames' "pos")."""

  def __init__(self) -> None:
    self.rows: list[dict] = []

  def tick(self, now, cells, stops, orders, **_) -> None:
    self.rows.append(dict(now=int(now), cells=[[int(c[0]), int(c[1])] for c in cells],
                          trays=[trays_on_board([(x.order_id, x.kind, x.cell) for x in lst], orders)
                                 for lst in stops]))


SIZES = (1, 2, 3, 5)
"""Order sizes in trays (problem statement section 4)."""


class Session:
  """A run the page advances step by step, so visitors can watch it and add orders.

  Only actions the frozen model allows: a new dynamic order between two stations of the
  layout, with a model size and priority; its deadline is the tightest the model's rule
  allows (at least twice the straight-line distance and at least 1.5 times an idle
  AGV's service time from the nearest warehouse). Orders keep their AGV; the fleet is
  fixed for the shift.
  """

  def __init__(self, layout: str, seed: int, agvs: int, shift: int = 3600,
               dispatcher: str = "reserve1", student: str | None = None) -> None:
    from factory_dispatch import insertion
    self._insertion = insertion
    self.args = dict(layout=layout, seed=seed, agvs=agvs, dispatcher=dispatcher)
    self.inst = with_fleet(demand_instance(layout_of(layout, seed), seed, shift=shift), agvs)
    self.disp = make_dispatcher(dispatcher, student)
    self.calls = 0
    session = self

    class Count:
      def decision(self, **kw) -> None:
        session.calls += 1

    inst = self.inst
    self._ticks = TickLog()
    self.sim = Simulation(inst.layout, list(inst.orders), self.disp, rules=inst.rules,
                          shift=inst.shift, homes=inst.homes, blocks=inst.blocks,
                          sec_per_eval=SEC_PER_EVAL, period=getattr(self.disp, "period", None),
                          recorders=[Count(), self._ticks])
    self.view = self.sim.reset()
    self.added: list[int] = []

  @property
  def finished(self) -> bool:
    return self.view is None

  @property
  def now(self) -> int:
    return self.sim._s.now

  def advance(self, seconds: int) -> None:
    """Run the simulation `seconds` further (as Simulation.run does, decision by decision)."""
    import time
    end = self.now + seconds
    while self.view is not None and self.now < end:
      e0 = self._insertion.eval_count()
      t0 = time.perf_counter()
      pairs = self.disp.decide(self.view)
      plan = self.disp.replan(self.view)
      ms = (time.perf_counter() - t0) * 1e3
      self.view = self.sim.step(pairs, plan, evals=self._insertion.eval_count() - e0, ms=ms)

  def ticks_since(self, k: int) -> list[dict]:
    """Ticks from index k on: {now, cells, trays} per tick, for the 3D view."""
    return self._ticks.rows[k:]

  def layout_info(self) -> dict:
    """Grid size, road cells, the grid as digit rows (0 wall, 1 road, 2 machine, 3/4 store
    zone, 8 floor), stations and warehouses, for drawing the layout."""
    import numpy as np
    lay = self.inst.layout
    roads = np.argwhere(lay.grid == 1).tolist()
    first = lambda d: {k: list(v[0]) for k, v in d.items()}  # noqa: E731
    grid = ["".join(str(int(v)) for v in row) for row in lay.grid]
    return dict(name=lay.name, height=int(lay.height), width=int(lay.width), roads=roads, grid=grid,
                stations=first(lay.stations), stores=first(lay.stores))

  def stations(self) -> list[str]:
    return sorted(self.inst.layout.stations)

  def order(self, oid: int) -> dict:
    o = self.sim._s.by_id[oid]
    return dict(id=o.id, pickup=list(o.pickup), dropoff=list(o.dropoff), arrival=o.arrival,
                deadline=o.deadline, priority=o.priority, size=o.size)

  def add_order(self, pickup: str, dropoff: str, priority: int, size: int) -> int:
    import dataclasses
    import math
    from factory_dispatch.orders import FEASIBLE_MARGIN, Order
    st = self.inst.layout.stations
    if pickup not in st or dropoff not in st or pickup == dropoff:
      raise ValueError("pick-up and drop-off must be two stations of the layout")
    if priority not in (1, 2, 3) or size not in SIZES:
      raise ValueError(f"priority 1-3 and size in {SIZES}")
    if self.finished:
      raise ValueError("the run has ended")
    s, idx = self.sim._s, self.sim.index
    a, b = st[pickup][0], st[dropoff][0]
    now = self.now
    oid = max(o.id for o in self.sim.orders) + 1
    o = Order(id=oid, pickup=a, dropoff=b, arrival=now, deadline=now, priority=priority,
              size=size)
    t = idx.dist_to(idx.ids[a])
    stores = [idx.ids[c[0]] for c in self.inst.layout.stores.values()]
    legs = min(t[x] for x in stores) + t[idx.ids[b]]
    floor = max(2 * (abs(a[0] - b[0]) + abs(a[1] - b[1])),
                math.ceil(FEASIBLE_MARGIN * (legs + 2 * self._insertion.dwell(o))))
    o = dataclasses.replace(o, deadline=now + floor)
    k = s.next_order
    while k < len(self.sim.orders) and self.sim.orders[k].arrival <= now:
      k += 1
    self.sim.orders.insert(k, o)
    s.by_id[oid] = o
    s.deadlines[oid] = o.deadline
    self.added.append(oid)
    return oid

  def delivered(self) -> dict[int, int]:
    return self.sim.delivered()

  def frame(self) -> dict:
    """What the page draws: AGVs, waiting orders, blocked cells, counters."""
    s, idx = self.sim._s, self.sim.index
    by_id = s.by_id
    agvs = []
    for i, p in enumerate(s.pos):
      held = sorted({st.order_id for st in s.stops[i]})
      agvs.append(dict(cell=list(idx.cells[p]), stops=len(s.stops[i]), load=s.load[i],
                       held=[by_id[h].priority for h in held if h in by_id]))
    waiting = [dict(id=o.id, pickup=list(o.pickup), dropoff=list(o.dropoff),
                    priority=o.priority, deadline=o.deadline)
               for o in (self.view.pending if self.view is not None else [])]
    done = s.done
    late = sum(1 for oid, t in done.items() if t > by_id[oid].deadline)
    return dict(now=self.now, agvs=agvs, waiting=waiting,
                blocked=[list(c) if isinstance(c, tuple) else list(idx.cells[c])
                         for c in sorted(s.closed)] if s.closed else [],
                delivered=len(done), late=late, added=list(self.added))

  def summary(self) -> dict:
    m = self.sim.metrics()
    return dict(layout=self.args["layout"], seed=self.args["seed"], agvs=self.args["agvs"],
                dispatcher=self.args["dispatcher"], orders=len(self.sim.orders),
                J=round(m.objective, 6), red_on_time=round(m.on_time_p1, 6),
                on_time=round(m.on_time_rate, 6), unfinished=int(m.unfinished),
                makespan=int(m.makespan), decisions=self.calls)
