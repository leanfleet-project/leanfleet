"""Discrete-time simulator: 1 tick = 1 cell. Dispatchers only assign orders."""

from __future__ import annotations

import copy
import math
import time
from dataclasses import dataclass, field

from factory_dispatch import insertion
from factory_dispatch.insertion import (
  MAX_COMMITTED,
  V1,
  Rules,
  Stop,
  best_insertion,
  dwell,
  evaluate,
)
from factory_dispatch.metrics import Metrics
from factory_dispatch.orders import PRIORITY_WEIGHT, Order
from factory_dispatch.routing import TimedRouter
from factory_dispatch.traffic import RoadIndex, Traffic
from factory_layout import FactoryLayout, build_road_graph
from factory_layout.layout import Cell


@dataclass
class AgvView:
  id: int
  cell: Cell
  stops: list[Stop]
  load: int
  home: Cell
  busy_until: int = 0
  """v2: end tick of a load or unload in progress, else the current tick."""


@dataclass
class SimView:
  now: int
  pending: list[Order]
  agvs: list[AgvView]
  index: RoadIndex
  q: int
  deadlines: dict[int, int]
  orders: dict[int, Order]
  future: list[Order] = field(default_factory=list)
  rules: Rules = V1
  planned: list[Order] = field(default_factory=list)
  """v2: planned orders already known but not yet arrived (cannot be assigned yet)."""
  blocked: frozenset = frozenset()
  """v2: road cells blocked right now."""
  blocked_since: dict = field(default_factory=dict)
  """v2: blocked cell -> tick its block started (its end is unknown)."""
  """Orders arriving within the dispatcher's look-ahead window, not yet held by
  any AGV. Empty for online dispatchers (window 0)."""


class Dispatcher:
  def decide(self, view: SimView) -> list[tuple[int, int]]:
    """(order id, agv id) pairs. Infeasible pairs are ignored; the order waits."""
    raise NotImplementedError

  def replan(self, view: SimView) -> dict[int, list[Stop]] | None:
    """Optional: full new stop lists. Picked-up orders must stay on their AGV."""
    return None

  lookahead: int = 0
  """Seconds of future orders this dispatcher may see. Online methods use 0."""

  def on_complete(self, order: Order, agv: int, finished: int) -> None:
    """Called when an order is delivered."""

  def on_pick(self, order: Order, agv: int, now: int) -> None:
    """Called when an order is loaded."""


def reconcile(
  plan: dict[int, list[Stop]],
  stops: list[list[Stop]],
  carrier: dict[int, int],
  done: set[int],
) -> dict[int, list[Stop]]:
  """Bring a plan computed from an older state up to date before applying it.

  While the plan was computed, AGVs kept driving their old stop lists: stops they
  served are gone, and an order the plan moved may already be on its old AGV.
  `carrier` maps each on-board order to the AGV carrying it.
  """
  out: dict[int, list[Stop]] = {}
  for a, lst in plan.items():
    keep = []
    for s in lst:
      if s.kind == "via":
        keep.append(s)
      elif s.order_id in done:
        continue
      elif s.kind == "pick" and s.order_id in carrier:
        continue
      elif s.kind == "drop" and carrier.get(s.order_id, a) != a:
        continue
      else:
        keep.append(s)
    out[a] = keep
  for oid, a in carrier.items():
    if a in out and not any(s.order_id == oid and s.kind == "drop" for s in out[a]):
      out[a].extend(s for s in stops[a] if s.order_id == oid and s.kind == "drop")
  return out


@dataclass
class _State:
  """Everything a run changes, so `Simulation.clone` can copy it."""
  pos: list = field(default_factory=list)
  home_ids: list = field(default_factory=list)
  stops: list = field(default_factory=list)
  load: list = field(default_factory=list)
  wait: list = field(default_factory=list)
  stuck: list = field(default_factory=list)
  serving: list = field(default_factory=list)
  """v2: (stop, end tick) of a load or unload in progress. It always finishes,
  even if a re-plan puts another stop first: loading cannot be interrupted."""
  agv_of: dict = field(default_factory=dict)
  picked: set = field(default_factory=set)
  done: dict = field(default_factory=dict)
  pending: dict = field(default_factory=dict)
  by_id: dict = field(default_factory=dict)
  deadlines: dict = field(default_factory=dict)
  m: Metrics = field(default_factory=Metrics)
  next_order: int = 0
  decision_times: list = field(default_factory=list)
  dirty: bool = True
  closed: frozenset = frozenset()
  end: int = 0
  inflight: tuple | None = None  # (ready, plan, pairs)
  now: int = 0
  view: SimView | None = None
  due: bool = False
  finished: bool = False
  planner: object = None


class Simulation:
  def __init__(
    self,
    layout: FactoryLayout,
    orders: list[Order],
    dispatcher: Dispatcher,
    q: int = 6,
    horizon: int = 9600,
    check_invariants: bool = False,
    index: RoadIndex | None = None,
    period: int | None = None,
    sec_per_eval: float | None = None,
    recorders: list | None = None,
    rules: Rules = V1,
    shift: int | None = None,
    blocks: list | None = None,
    homes: list[Cell] | None = None,
    timed_routing: bool | None = None,
    safety_gap: int | None = None,
    traffic: str | None = None,
  ) -> None:
    """`safety_gap`: 1 keeps one empty cell between AGVs (see `Traffic`).
    `timed_routing` and `safety_gap` default to the frozen v2 traffic rules (both
    on, 2026-11-08) for v2 runs and to the original rule (both off) for v1.
    `timed_routing`: routes take the plan's known stops into account (see
    `routing.py`) instead of always being the shortest path.
    `sec_per_eval`: if set, a decision takes effect ceil(evaluations x this)
    ticks after it starts, and no new decision starts meanwhile. Evaluations are
    counted by `insertion.eval_count`, so results stay deterministic.
    `recorders`: objects with optional `decision(**info)` and `tick(**state)`.
    `traffic`: "central" (the rule from 2026-11-12: one planner reserves cells over
    time for every AGV, see `planner.py`) or "pibt" (the earlier rule: per-AGV
    routing plus PIBT, kept for regression tests). Default: central for v2 runs."""
    self.layout = layout
    self.orders = orders
    self.dispatcher = dispatcher
    self.q = q
    self.horizon = horizon
    self.check = check_invariants
    self.period = period
    self.rules = rules
    self.blocks = list(blocks or [])
    if rules.v2:
      # A shift runs until every order is delivered, capped at three shifts.
      self.shift = shift if shift is not None else horizon
      self.horizon = 3 * self.shift
    self.sec_per_eval = sec_per_eval
    self.recorders = list(recorders or [])
    self.index = index or RoadIndex(build_road_graph(layout))
    if traffic is None:
      traffic = "central" if rules.v2 else "pibt"
    if traffic not in ("central", "pibt") or (traffic == "central" and not rules.v2):
      raise ValueError(f"traffic {traffic!r} needs v2 rules for central")
    if traffic == "central" and (timed_routing is not None or safety_gap is not None):
      raise ValueError("timed_routing and safety_gap belong to traffic='pibt'")
    self.traffic_mode = traffic
    if timed_routing is None:
      timed_routing = rules.v2
    if safety_gap is None:
      safety_gap = 1 if rules.v2 else 0
    self.traffic = Traffic(self.index, zone_lock=rules.v2, gap=safety_gap)
    self.router = TimedRouter(self.index) if timed_routing else None
    labels = sorted(layout.stores, key=int)
    self.homes = list(homes) if homes is not None else [layout.stores[k][0] for k in labels]

  # ---- reset / step / clone ------------------------------------------------
  # `run()` is reset() then decide/step until the run ends. A step stops at each
  # decision, so a caller can copy the state (`clone`) and try other decisions.

  def run(self) -> Metrics:
    view = self.reset()
    while view is not None:
      e0 = insertion.eval_count()
      t0 = time.perf_counter()
      pairs = self.dispatcher.decide(view)
      plan = self.dispatcher.replan(view)
      ms = (time.perf_counter() - t0) * 1e3
      view = self.step(pairs, plan, evals=insertion.eval_count() - e0, ms=ms)
    return self.metrics()

  def reset(self) -> SimView | None:
    """Start a run; returns the first decision's view, or None if the run ends first."""
    index = self.index
    n = len(self.homes)
    s = _State()
    s.pos = [index.ids[h] for h in self.homes]
    s.home_ids = list(s.pos)
    s.stops = [[] for _ in range(n)]
    s.load = [0] * n
    s.wait = [0] * n
    s.stuck = [0] * n
    s.serving = [None] * n
    s.by_id = {o.id: o for o in self.orders}
    s.deadlines = {o.id: o.deadline for o in self.orders}
    s.end = self.horizon
    if self.traffic_mode == "central":
      from factory_dispatch.planner import CentralPlanner
      s.planner = CentralPlanner(index, s.home_ids)
    self._s = s
    index.set_blocked(())
    return self._advance()

  def view(self) -> SimView | None:
    """The decision the run is stopped at, or None once it has ended."""
    return None if self._s.finished else self._s.view

  def step(self, pairs, plan: dict[int, list[Stop]] | None = None, *, evals: int = 0,
           ms: float = 0.0) -> SimView | None:
    """Apply the decision for the current view and run to the next one.
    `evals` (insertion evaluations the decision took) sets its latency when
    `sec_per_eval` is on; `ms` is only recorded."""
    s = self._s
    if s.finished or s.view is None:
      raise RuntimeError("no decision pending")
    self.index.set_blocked(s.closed)  # A clone may have moved the shared index on.
    now = s.now
    s.decision_times.append(ms)
    extra = getattr(self.dispatcher, "extra_sec", 0.0)
    delay = math.ceil(evals * self.sec_per_eval + extra) if self.sec_per_eval else 0
    for r in self.recorders:
      if hasattr(r, "decision"):
        r.decision(now=now, view=s.view, plan=plan, pairs=pairs, evals=evals, ms=ms,
                   delay=delay, round=s.due)
    s.view = None
    if delay > 0:
      s.inflight = (now + delay, plan, list(pairs))
      s.dirty = False
    else:
      self._apply(plan, pairs)
      s.dirty = self._serve()  # An AGV may already stand on a stop it was just given.
    self._move()
    s.now += 1
    return self._advance()

  def metrics(self) -> Metrics:
    s = self._s
    return self._metrics(s.m, s.done, s.pending, s.agv_of, s.picked, s.decision_times,
                         s.next_order, s.end)

  @property
  def state(self) -> _State:
    """The run's mutable state (read it, do not change it)."""
    return self._s

  def delivered(self) -> dict[int, int]:
    """Order id -> tick it was delivered, for the orders delivered so far."""
    return dict(self._s.done)

  def clone(self, dispatcher: Dispatcher | None = None,
            future: list[Order] | None = None) -> "Simulation":
    """An independent copy of the run so far. The road index, layout and orders
    are shared (they do not change, except the index's blocked set, which every
    step restores). `dispatcher`: the copy's dispatcher; default a deep copy.
    `future`: replaces the orders not arrived yet (ids must continue from the
    arrived ones, sorted by arrival); the copy then faces another future."""
    memo = {id(self.index): self.index, id(self.layout): self.layout,
            id(self.orders): self.orders}
    for o in self.orders:
      memo[id(o)] = o
    if dispatcher is not None:
      memo[id(self.dispatcher)] = dispatcher
    twin = copy.deepcopy(self, memo)
    if future is not None:
      s = twin._s
      k = s.next_order
      held = {x.order_id for lst in s.stops for x in lst}
      if any(i >= k for i in held) or any(o.id != k + j for j, o in enumerate(future)):
        raise ValueError("future must follow the arrived orders, and none may be held")
      twin.orders = self.orders[:k] + list(future)
      s.by_id = {o.id: o for o in twin.orders}
      s.deadlines = {o.id: o.deadline for o in twin.orders}
    return twin

  # ---- one tick, split at the decision ----------------------------------------

  def _advance(self) -> SimView | None:
    """Run ticks until a decision is due (returns its view) or the run ends (None)."""
    s = self._s
    index = self.index
    rules = self.rules
    while True:
      now = s.now
      if self.blocks:
        active = frozenset(
          index.ids[c] for b in self.blocks if b.start <= now < b.end for c in b.cells
          if c in index.ids
        )
        if active != s.closed:
          s.closed = active
          index.set_blocked(s.closed)
          s.dirty = True  # Distances changed: a chance to replan.
      while s.next_order < len(self.orders) and self.orders[s.next_order].arrival <= now:
        o = self.orders[s.next_order]
        if o.id not in s.agv_of:  # A look-ahead plan may already hold it.
          s.pending[o.id] = o
        s.next_order += 1
        s.dirty = True

      s.dirty = self._serve() or s.dirty
      if now == self.horizon or (
        rules.v2 and s.next_order == len(self.orders) and len(s.done) == len(self.orders)
      ):
        s.end = now
        s.finished = True
        return None

      if s.inflight is not None and now >= s.inflight[0]:
        _, plan, pairs = s.inflight
        s.inflight = None
        self._apply(self._refresh(plan) if plan is not None else None, pairs)
        s.dirty = self._serve() or s.dirty

      due = self.period is not None and now % self.period == 0
      if (s.dirty or due) and s.inflight is None:
        view = self._view(now, s.pending, s.pos, s.stops, s.load, s.deadlines, s.by_id)
        for a, sv in enumerate(s.serving):
          view.agvs[a].busy_until = sv[1] if sv is not None else now
        view.rules = rules
        view.blocked = frozenset(index.cells[i] for i in s.closed)
        view.blocked_since = {
          c: b.start for b in self.blocks if b.start <= now < b.end for c in b.cells
        }
        if rules.v2:
          view.planned = [
            o for o in self.orders[s.next_order:] if o.planned and 0 <= o.known_at <= now
          ]
        window = self.dispatcher.lookahead
        if window > 0:
          held = {x.order_id for lst in s.stops for x in lst}
          k = s.next_order
          while k < len(self.orders) and self.orders[k].arrival <= now + window:
            if self.orders[k].id not in held:
              view.future.append(self.orders[k])
            k += 1
        s.view = view
        s.due = due
        return view
      self._move()
      s.now += 1

  def _apply(self, plan, pairs) -> None:
    s = self._s
    n = len(s.pos)
    if plan is not None:
      self._apply_plan(plan, s.stops, s.agv_of, s.picked, s.pending, s.by_id, s.now)
    for oid, a in pairs:
      o = s.pending.get(oid)
      if o is None or not 0 <= a < n:
        continue
      ins = best_insertion(
        self.index.cells[s.pos[a]], s.stops[a], s.load[a], o, s.now, self.index, self.q,
        s.by_id, rules=self.rules,
      )
      if ins is None:
        continue
      s.stops[a] = ins.stops
      s.agv_of[oid] = a
      del s.pending[oid]

  def _refresh(self, plan):
    """A late plan, minus what happened while it was computed."""
    s = self._s
    carrier = {o: s.agv_of[o] for o in s.picked if o not in s.done}
    plan = reconcile(plan, s.stops, carrier, set(s.done))
    for a, lst in plan.items():
      commits = s.load[a] + sum(x.kind == "pick" for x in lst)
      ok = commits <= MAX_COMMITTED and evaluate(
        self.index.cells[s.pos[a]], lst, s.load[a], self.q, s.now, self.index, s.by_id,
        self.rules,
      ) is not None
      if not ok:  # Keep its current list; orders new in this plan stay pending.
        plan[a] = list(s.stops[a])
    return plan

  def _serve(self) -> bool:
    """Service on arrival: several stops on one cell can clear in one tick."""
    s = self._s
    now = s.now
    index = self.index
    stops, serving, by_id = s.stops, s.serving, s.by_id
    served = False
    for a in range(len(s.pos)):
      while stops[a]:
        if serving[a] is not None:
          x, finish = serving[a]
          if now < finish:
            break  # Still loading or unloading.
          serving[a] = None
          stops[a].remove(x)
        else:
          head = stops[a][0]
          if index.ids[head.cell] != s.pos[a]:
            break
          if head.kind == "pick" and by_id[head.order_id].arrival > now:
            break  # Arrived early: wait for the order to exist.
          if self.rules.v2 and head.kind != "via":
            serving[a] = (head, now + dwell(by_id[head.order_id]))
            continue
          x = stops[a].pop(0)
        s.wait[a] = 0
        served = True
        if x.kind == "via":
          continue
        if x.kind == "pick":
          s.load[a] += 1
          s.picked.add(x.order_id)
          self.dispatcher.on_pick(by_id[x.order_id], a, now)
        else:
          s.load[a] -= 1
          s.done[x.order_id] = now
          self.dispatcher.on_complete(by_id[x.order_id], a, now)
    return served

  def _move(self) -> None:
    """Tick recorders, then every AGV moves at most one cell."""
    s = self._s
    now = s.now
    index = self.index
    n = len(s.pos)
    pos, stops, serving, by_id, wait, stuck, m = (
      s.pos, s.stops, s.serving, s.by_id, s.wait, s.stuck, s.m)
    for r in self.recorders:
      if hasattr(r, "tick"):
        r.tick(now=now, cells=[index.cells[p] for p in pos], stops=stops, load=s.load,
               pending=s.pending, done=s.done, orders=by_id, agv_of=s.agv_of,
               blocked=[index.cells[i] for i in sorted(s.closed)],
               serving=[x is not None for x in serving])

    # Busy AGVs outrank idle ones and rise the longer they wait.
    goals: list[int | None] = []
    prio: list[float] = []
    for a in range(n):
      head = stops[a][0] if stops[a] else None
      early = head is not None and head.kind == "pick" and (
        by_id[head.order_id].arrival > now
      )
      if serving[a] is not None:
        goals.append(pos[a])  # Serving: holds its cell, cannot be pushed.
        prio.append(1e9 + a)
        wait[a] = 0
      elif early and pos[a] == index.ids[head.cell]:
        # Waiting for an order that does not exist yet: yield like an idle AGV,
        # or it would hold a one-lane road for the whole wait.
        goals.append(pos[a])
        prio.append((a + 1) * 1e-6)
        wait[a] = 0
      elif head is not None:
        goals.append(index.ids[head.cell])
        prio.append(1.0 + wait[a] + (a + 1) * 1e-3)
      else:
        goals.append(s.home_ids[a] if pos[a] != s.home_ids[a] else None)
        prio.append((a + 1) * 1e-6)
    if s.planner is not None:
      new = s.planner.step(now, pos, stops, serving, by_id, s.closed)
      m.plan_failures = s.planner.failures
      m.plan_deviations = s.planner.deviations
    else:
      prefer = (
        self.router.next_cells(now, pos, goals, stops, serving, by_id) if self.router else None
      )
      new = self.traffic.step(pos, goals, prio, prefer)
      m.gap_relaxed_moves += len(self.traffic.relaxed)
    if self.check:
      self._assert_valid(pos, new)
      assert all(q == p or q not in s.closed for p, q in zip(pos, new)), "entered a block"
      if self.traffic.gap and s.planner is None:
        for a in range(n):
          if new[a] != pos[a] and a not in self.traffic.relaxed:
            assert not any(new[b] in index.nbrs[new[a]] for b in range(n) if b != a), (
              "moved next to an AGV")
    for a in range(n):
      if new[a] != pos[a]:
        m.distance += 1
      head = stops[a][0] if stops[a] else None
      waiting = head is not None and head.kind == "pick" and (
        by_id[head.order_id].arrival > now
      )
      if head is not None and not waiting and serving[a] is None:
        wait[a] += 1
        table = index.dist_to(goals[a])  # type: ignore[arg-type]
        # On a planned detour the distance may grow while the AGV is moving on.
        if table[new[a]] < table[pos[a]] or (self.router and new[a] != pos[a]):
          stuck[a] = 0
        else:
          stuck[a] += 1
          m.blocked_ticks += 1
          m.max_stuck_ticks = max(m.max_stuck_ticks, stuck[a])
      else:
        stuck[a] = 0
    s.pos = new

  def _view(self, now, pending, pos, stops, load, deadlines, by_id) -> SimView:
    agvs = [
      AgvView(a, self.index.cells[pos[a]], list(stops[a]), load[a], self.homes[a], now)
      for a in range(len(pos))
    ]
    return SimView(
      now, list(pending.values()), agvs, self.index, self.q, deadlines, by_id
    )

  def _apply_plan(self, plan, stops, agv_of, picked, pending, by_id, now) -> None:
    # Problem model (spec 4.1): the AGV an order is given to carries it to delivery.
    for a, new_stops in plan.items():
      for s in new_stops:
        if s.kind != "via" and agv_of.get(s.order_id, a) != a:
          raise ValueError(f"plan would reassign order {s.order_id} to AGV {a}")
    kept = {s.order_id for a, lst in plan.items() for s in lst if s.kind != "via"}
    for a in plan:
      for s in stops[a]:
        if s.kind != "via" and s.order_id not in kept:
          raise ValueError(f"plan would unassign order {s.order_id} from AGV {a}")
    for a, new_stops in plan.items():
      for s in new_stops:
        if s.kind == "via":
          continue
        if s.kind == "pick" and s.order_id in pending:
          del pending[s.order_id]
        agv_of[s.order_id] = a
      stops[a] = list(new_stops)
    held = {s.order_id for lst in stops for s in lst if s.kind != "via"}
    for oid, a in list(agv_of.items()):
      if oid not in held and oid not in picked:
        if by_id[oid].arrival <= now:
          pending[oid] = by_id[oid]
        del agv_of[oid]
    if self.check:
      for lst in stops:
        for s in lst:
          assert s.kind != "pick" or s.order_id not in picked

  @staticmethod
  def _assert_valid(old: list[int], new: list[int]) -> None:
    assert len(set(new)) == len(new), "vertex conflict"
    where = {p: i for i, p in enumerate(old)}
    for i, c in enumerate(new):
      j = where.get(c)
      if j is not None and j != i:
        assert new[j] != old[i], "swap conflict"

  def _metrics(self, m, done, pending, agv_of, picked, times, seen, end) -> Metrics:
    if self.rules.v2:
      return self._metrics_v2(m, done, pending, agv_of, picked, times, end)
    on_time = counted = 0
    flow = 0
    cls_on = {1: 0, 2: 0, 3: 0}
    cls_n = {1: 0, 2: 0, 3: 0}
    for o in self.orders[:seen]:
      if o.id in done:
        finished = done[o.id]
        late = max(0, finished - o.deadline)
        flow += finished - o.arrival
      elif o.deadline <= self.horizon:
        late = self.horizon - o.deadline
      else:
        m.censored += 1
        continue
      counted += 1
      cls_n[o.priority] += 1
      if late == 0 and o.id in done:
        on_time += 1
        cls_on[o.priority] += 1
      m.total_tardiness += late
      m.weighted_tardiness += PRIORITY_WEIGHT[o.priority] * late
      if o.priority == 3:
        m.max_lateness_p3 = max(m.max_lateness_p3, late)
    m.on_time_p1 = cls_on[1] / cls_n[1] if cls_n[1] else 1.0
    m.on_time_p2 = cls_on[2] / cls_n[2] if cls_n[2] else 1.0
    m.on_time_p3 = cls_on[3] / cls_n[3] if cls_n[3] else 1.0
    m.completed = len(done)
    m.unservable = getattr(self.dispatcher, "unservable", 0)
    m.on_time_rate = on_time / counted if counted else 0.0
    m.mean_flow_time = flow / len(done) if done else 0.0
    m.throughput_per_hour = len(done) * 3600 / self.horizon
    m.unassigned_end = len(pending)
    m.on_board_end = sum(1 for o in picked if o not in done)
    m.assigned_end = sum(1 for o in agv_of if o not in done and o not in picked)
    if times:
      m.decision_ms_mean = sum(times) / len(times)
      m.decision_ms_max = max(times)
    return m

  def _metrics_v2(self, m, done, pending, agv_of, picked, times, end) -> Metrics:
    """Every order counts; an unfinished one is late until the run's end."""
    cls_on = {1: 0, 2: 0, 3: 0}
    cls_n = {1: 0, 2: 0, 3: 0}
    on_time = 0
    for o in self.orders:
      finished = done.get(o.id)
      t = finished if finished is not None else end
      late = max(0, t - o.deadline)
      cls_n[o.priority] += 1
      if finished is not None and late == 0:
        on_time += 1
        cls_on[o.priority] += 1
      else:
        m.unfinished += finished is None
      m.total_tardiness += late
      m.weighted_tardiness += PRIORITY_WEIGHT[o.priority] * late
      m.total_flow_time += t - o.arrival if o.arrival <= t else 0
      if o.priority == 3:
        m.max_lateness_p3 = max(m.max_lateness_p3, late)
    m.objective = m.weighted_tardiness + self.rules.lam * m.total_flow_time
    m.on_time_rate = on_time / len(self.orders) if self.orders else 1.0
    for p in (1, 2, 3):
      setattr(m, f"on_time_p{p}", cls_on[p] / cls_n[p] if cls_n[p] else 1.0)
    m.completed = len(done)
    m.makespan = max(done.values()) if len(done) == len(self.orders) and done else end
    m.mean_flow_time = (
      sum(done[i] - self.orders[i].arrival for i in done) / len(done) if done else 0.0
    )
    m.throughput_per_hour = len(done) * 3600 / max(1, end)
    m.unassigned_end = len(pending)
    m.on_board_end = sum(1 for o in picked if o not in done)
    m.assigned_end = sum(1 for o in agv_of if o not in done and o not in picked)
    m.unservable = getattr(self.dispatcher, "unservable", 0)
    if times:
      m.decision_ms_mean = sum(times) / len(times)
      m.decision_ms_max = max(times)
    return m
