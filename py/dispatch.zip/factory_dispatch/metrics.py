"""What an experiment reports."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Metrics:
  on_time_rate: float = 0.0
  """Share on time among orders whose deadline fell within the horizon or that
  finished. Orders still open with a later deadline are censored, not counted."""
  total_tardiness: float = 0.0
  weighted_tardiness: float = 0.0
  """Lateness weighted by priority (10 / 1 / 0.2). The headline objective."""
  on_time_p1: float = 1.0
  on_time_p2: float = 1.0
  on_time_p3: float = 1.0
  max_lateness_p3: float = 0.0
  completed: int = 0
  censored: int = 0
  throughput_per_hour: float = 0.0
  mean_flow_time: float = 0.0
  distance: int = 0
  blocked_ticks: int = 0
  """Agent-ticks where an AGV with a stop to reach got no closer."""
  max_stuck_ticks: int = 0
  """Longest time one AGV went without getting closer to its next stop."""
  gap_relaxed_moves: int = 0
  """Safety gap on: moves that ended next to another AGV (creep mode after waiting)."""
  plan_failures: int = 0
  """Central routing: AGV-ticks standing still because no plan was found."""
  plan_deviations: int = 0
  """Central routing: planned moves cancelled by the final safety check."""
  decision_ms_mean: float = 0.0
  decision_ms_max: float = 0.0
  on_board_end: int = 0
  assigned_end: int = 0
  unassigned_end: int = 0
  unservable: int = 0
  total_flow_time: float = 0.0
  """v2: sum over orders of (delivered or run end) - arrival."""
  objective: float = 0.0
  """v2: J_lambda = weighted tardiness + lambda * total flow time."""
  makespan: int = 0
  """v2: last delivery, or the run's end if orders remain."""
  unfinished: int = 0
