"""Fleet size decoupled from the number of stores."""

from __future__ import annotations

from collections import deque

from factory_layout import FactoryLayout, build_road_graph
from factory_layout.layout import Cell


def fleet_homes(layout: FactoryLayout, n: int) -> list[Cell]:
  """Start and parking cells for `n` AGVs: the store cells first (label order),
  then the road cells nearest any store, never a store or station cell."""
  stores = [layout.stores[k][0] for k in sorted(layout.stores, key=int)]
  if n <= len(stores):
    return stores[:n]
  graph = build_road_graph(layout)
  named = {c for g in (layout.stores, layout.stations) for cells in g.values() for c in cells}
  dist = {c: 0 for c in stores}
  queue = deque(stores)
  while queue:
    c = queue.popleft()
    for nb in sorted(graph.neighbours(c)):
      if nb not in dist:
        dist[nb] = dist[c] + 1
        queue.append(nb)
  extra = sorted((d, c) for c, d in dist.items() if c not in named)
  homes = stores + [c for _, c in extra[: n - len(stores)]]
  if len(homes) < n:
    raise ValueError(f"{layout.name}: only {len(homes)} cells for {n} AGVs")
  return homes
