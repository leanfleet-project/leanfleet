"""Provenance for result directories: who ran what, with which code, on which problem.

`start_meta` appends one invocation to `<out>/meta.json` and saves a tarball of the
dispatch code (`code_<sha12>.tar.gz`, a few hundred KB) so any number can be traced
back to the exact code that made it, even without a commit. `finish_meta` marks it done.
"""

from __future__ import annotations

import datetime as _dt
import hashlib
import io
import json
import platform
import subprocess
import sys
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]  # mjlab_mir/
CODE_DIRS = ("src/factory_dispatch", "src/factory_layout", "scripts")
# In the repo the problem statement sits next to mjlab_mir/; on the remote copy it is
# synced into mjlab_mir/docs/.
_DOC = "docs/research/2026-11-08-problem-statement.md"
PROBLEM = next((p for p in (ROOT.parent / _DOC, ROOT / _DOC) if p.exists()), ROOT.parent / _DOC)
PAPER_SEED_MIN = 2000


def _now() -> str:
  return _dt.datetime.now().astimezone().isoformat(timespec="seconds")


def _code_files() -> list[Path]:
  return sorted(p for d in CODE_DIRS for p in (ROOT / d).rglob("*.py")
                if "__pycache__" not in p.parts)


def code_hash() -> str:
  h = hashlib.sha256()
  for p in _code_files():
    h.update(str(p.relative_to(ROOT)).encode() + b"\0" + p.read_bytes() + b"\0")
  return h.hexdigest()


def _snapshot(out: Path, sha: str) -> str:
  name = f"code_{sha[:12]}.tar.gz"
  if not (out / name).exists():
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as t:
      for p in _code_files():
        t.add(p, arcname=str(p.relative_to(ROOT)))
    (out / name).write_bytes(buf.getvalue())
  return name


def _git(*args: str) -> str | None:
  try:
    r = subprocess.run(["git", *args], cwd=ROOT, capture_output=True, text=True, timeout=10)
  except (OSError, subprocess.TimeoutExpired):
    return None
  return r.stdout.strip() if r.returncode == 0 else None


def _seed_kind(args: dict) -> str | None:
  base = args.get("seed_base")
  if base is None:
    return None
  return "paper" if base >= PAPER_SEED_MIN else "dev"


def _traffic_default() -> str:
  from factory_dispatch.insertion import Rules
  from factory_dispatch.sim import Simulation
  from factory_layout import load_layout
  from factory_dispatch.baselines import NearestDispatcher
  return Simulation(load_layout("map1a"), [], NearestDispatcher(),
                    rules=Rules(v2=True)).traffic_mode


def _load(out: Path) -> dict:
  f = out / "meta.json"
  return json.loads(f.read_text()) if f.exists() else {"invocations": []}


def _save(out: Path, m: dict) -> None:
  (out / "meta.json").write_text(json.dumps(m, indent=2, ensure_ascii=False) + "\n")


def start_meta(out, argv: list[str], args: dict, purpose: str | None = None) -> int:
  """Record a new invocation; returns its index for `finish_meta`."""
  out = Path(out)
  out.mkdir(parents=True, exist_ok=True)
  import torch
  sha = code_hash()
  status = _git("status", "--porcelain")
  inv = dict(
    start=_now(), status="running", purpose=purpose, argv=list(argv), args=dict(args),
    seed_kind=_seed_kind(args), host=platform.node(), python=sys.version.split()[0],
    torch=torch.__version__, git_commit=_git("rev-parse", "HEAD"),
    git_branch=_git("rev-parse", "--abbrev-ref", "HEAD"),
    git_dirty=None if status is None else bool(status),
    code_sha256=sha, code_snapshot=_snapshot(out, sha),
    problem_sha256=hashlib.sha256(PROBLEM.read_bytes()).hexdigest() if PROBLEM.exists() else None,
    traffic_default=_traffic_default(),
  )
  m = _load(out)
  m["invocations"].append(inv)
  _save(out, m)
  return len(m["invocations"]) - 1


def finish_meta(out, index: int, **extra) -> None:
  out = Path(out)
  m = _load(out)
  m["invocations"][index].update({"status": "finished", "end": _now(), **extra})
  _save(out, m)
