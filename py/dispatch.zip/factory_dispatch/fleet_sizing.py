"""Minimum fleet for a fixed demand (spec 4.5, defined by the authors 2026-11-07).

A plant pays per AGV: the best dispatcher is the one that meets the service target
with the fewest AGVs. The demand of a layout is fixed (calibrated once on its
nominal fleet) and the fleet is swept downwards from there."""

from __future__ import annotations

import dataclasses
import math

from factory_dispatch.fleet import fleet_homes
from factory_dispatch.instances import Instance, make_instance, max_fleet, nominal_fleet
from factory_dispatch.metrics import Metrics
from factory_layout import FactoryLayout

RED_TARGET = 0.95
ALL_TARGET = 0.90
RED_LEVELS = (0.90, 0.95, 0.99)
RHO_REF = 0.5
FRACTIONS = (0.5, 0.6, 0.7, 0.8, 0.9, 1.0)


def meets(m: Metrics, red: float = RED_TARGET, all_: float = ALL_TARGET) -> bool:
  """Service target: nothing left undelivered, red and overall on-time shares."""
  return m.unfinished == 0 and m.on_time_p1 >= red and m.on_time_rate >= all_


def min_fleet(results: dict[int, Metrics], **target) -> int | None:
  """Smallest swept fleet size that meets the target, None if none does."""
  ok = [n for n, m in results.items() if meets(m, **target)]
  return min(ok) if ok else None


def demand_instance(layout: FactoryLayout, seed: int, rho: float = RHO_REF, lam: float = 0.1,
                    block_rate: float = 4.0, shift: int = 3600) -> Instance:
  """Orders calibrated to utilization `rho` on the layout's nominal fleet."""
  n_ref = nominal_fleet(layout)
  return make_instance(layout, n_ref, rho, lam, block_rate, seed, shift, n_ref=n_ref)


def with_fleet(inst: Instance, n: int) -> Instance:
  """Same orders, blocks and rules with `n` AGVs starting at the warehouse."""
  if not 1 <= n <= max_fleet(inst.layout):
    raise ValueError(f"fleet {n} outside 1..{max_fleet(inst.layout)}")
  return dataclasses.replace(inst, homes=fleet_homes(inst.layout, n),
                             meta={**inst.meta, "agvs": n})


def candidate_fleets(layout: FactoryLayout, fractions=FRACTIONS) -> list[int]:
  """Half to all of the nominal fleet, about 10% apart (`fractions`: a subset, for
  screening runs)."""
  n_ref = nominal_fleet(layout)
  return sorted({max(1, min(n_ref, round(f * n_ref))) for f in fractions})


def min_fleet_table(rows: list[dict], levels=RED_LEVELS, all_: float = ALL_TARGET
                    ) -> dict[tuple, dict[float, int | None]]:
  """Rows (layout, seed, config, agvs, unfinished, red, ontime) -> per
  (layout, seed, config) the minimum fleet at each red on-time level."""
  groups: dict[tuple, dict[int, Metrics]] = {}
  for r in rows:
    m = Metrics(on_time_p1=float(r["red"]), on_time_rate=float(r["ontime"]),
                unfinished=int(r["unfinished"]))
    groups.setdefault((r["layout"], int(r["seed"]), r["config"]), {})[int(r["agvs"])] = m
  return {k: {lv: min_fleet(g, red=lv, all_=all_) for lv in levels} for k, g in groups.items()}


def _size(r: dict, varies: bool) -> float:
  """Fleet key: the AGV count, or for a layout drawn per seed (its nominal fleet
  varies) the nearest swept share of the nominal fleet."""
  if not varies:
    return int(r["agvs"])
  share = int(r["agvs"]) / int(r["n_ref"])
  return min(FRACTIONS, key=lambda f: (abs(f - share), -f))


def _groups(rows: list[dict]) -> dict[tuple, list[dict]]:
  refs: dict[str, set] = {}
  for r in rows:
    refs.setdefault(r["layout"], set()).add(r.get("n_ref"))
  g: dict[tuple, list[dict]] = {}
  for r in rows:
    key = _size(r, len(refs[r["layout"]]) > 1)
    g.setdefault((r["layout"], r["config"], key), []).append(r)
  return g


def _pool(rs: list[dict]) -> tuple[int, float, float]:
  """(unfinished, red on-time share, overall on-time share) over all orders of `rs`."""
  red_n = sum(int(r["red_n"]) for r in rs)
  orders = sum(int(r["orders"]) for r in rs)
  return (sum(int(r["unfinished"]) for r in rs),
          sum(int(r["red_ok"]) for r in rs) / red_n if red_n else 1.0,
          sum(int(r["ok"]) for r in rs) / orders if orders else 1.0)


def pooled_min_fleet(rows: list[dict], levels=RED_LEVELS, all_: float = ALL_TARGET
                     ) -> dict[tuple, dict[float, int | None]]:
  """Per (layout, config): the smallest swept fleet from which every larger swept
  fleet meets the target, on-time shares counted over the orders of all seeds
  (rows need unfinished, red_ok, red_n, ok, orders; n_ref for layouts drawn per
  seed, whose minimum is then a share of the nominal fleet). A single seed holds too few
  red orders (3 to 8 on map1a) for its own share to mean anything."""
  pooled = {k: _pool(rs) for k, rs in _groups(rows).items()}
  out: dict[tuple, dict[float, int | None]] = {}
  for lay, cfg in sorted({k[:2] for k in pooled}):
    sizes = sorted(n for (l, c, n) in pooled if (l, c) == (lay, cfg))
    res = {}
    for lv in levels:
      best = None
      for n in reversed(sizes):
        unf, red, ok = pooled[(lay, cfg, n)]
        if unf or red < lv or ok < all_:
          break
        best = n
      res[lv] = best
    out[(lay, cfg)] = res
  return out


def service_curve(rows: list[dict], boot: int = 1000, rng_seed: int = 0,
                  alpha: float = 0.05) -> dict[tuple, dict[str, float]]:
  """Per (layout, config, fleet): pooled red and overall on-time shares with
  percentile bootstrap bounds, seeds resampled with replacement."""
  import random
  rng = random.Random(rng_seed)
  out = {}
  for k, rs in sorted(_groups(rows).items()):
    _, red, ok = _pool(rs)
    reds, oks = [], []
    for _ in range(boot):
      _, r, o = _pool([rng.choice(rs) for _ in rs])
      reds.append(r)
      oks.append(o)
    reds.sort()
    oks.sort()
    lo, hi = int(alpha / 2 * boot), int((1 - alpha / 2) * boot) - 1
    out[k] = dict(red=red, red_lo=reds[lo], red_hi=reds[hi], all=ok, all_lo=oks[lo],
                  all_hi=oks[hi], seeds=len(rs))
  return out


def _p90(xs: list[int]) -> int:
  """90th percentile by nearest rank."""
  xs = sorted(xs)
  return xs[max(0, math.ceil(0.9 * len(xs)) - 1)]


def delivery_at_min(rows: list[dict], level: float = RED_TARGET, all_: float = ALL_TARGET
                    ) -> dict[tuple, dict | None]:
  """Per (layout, config): delivery time (delivered - arrival, seconds) over all
  orders of all seeds at that config's pooled minimum fleet: {fleet, mean, p90},
  or None without a minimum fleet. Fewer AGVs only count if deliveries stay fast."""
  table = pooled_min_fleet(rows, levels=(level,), all_=all_)
  groups = _groups(rows)
  out: dict[tuple, dict | None] = {}
  for (lay, cfg), res in table.items():
    n = res[level]
    if n is None:
      out[(lay, cfg)] = None
      continue
    flows = [int(x) for r in groups[(lay, cfg, n)] for x in str(r["flows"]).split(";") if x]
    out[(lay, cfg)] = dict(fleet=n, mean=sum(flows) / len(flows), p90=_p90(flows))
  return out
