"""Centralized routing, the traffic rule from 2026-11-12 (problem statement §5).

One planner routes every AGV and reserves cells over time:
- No two AGVs share a cell or swap cells.
- Two moving AGVs always keep one empty cell between them, so there is no head-on
  meeting and no tailgating.
- A moving AGV may pass an AGV that stands still (loading, unloading, or parked).
- Nobody enters a blocked cell. The planner does not know when a block will end.

An AGV's plan covers its whole stop list, loading and unloading included, then the
way home. Once it is home (or wherever it parks), it is "parked": that tail is a
soft reservation. Another AGV may plan through a parked AGV's cell; the parked one
is then re-planned to step aside and come back later.

Plans are made one AGV at a time against the plans already made (prioritised
planning), each with Safe Interval Path Planning (SIPP, Phillips & Likhachev, ICRA
2011). An AGV that cannot be planned stands still and is retried the next tick. A
final check before each move keeps the rule even if a plan went stale; such stops
are counted as deviations.
"""

from __future__ import annotations

import heapq
from collections import deque
from dataclasses import dataclass

from factory_dispatch.insertion import Stop, dwell
from factory_dispatch.orders import Order
from factory_dispatch.traffic import UNREACHABLE, RoadIndex

INF = 10**9
HOLD = 5
"""Ticks an AGV without a plan blocks its cell for everyone."""


def safe_intervals(busy: list[tuple[int, int]], start: int = 0) -> list[tuple[int, int]]:
  """Free spans [s, e] (inclusive) from `start` on, given busy spans [s, e]."""
  out = []
  t = start
  for s, e in sorted(busy):
    if e < t:
      continue
    if s > t:
      out.append((t, s - 1))
    t = max(t, e + 1)
    if t > INF:
      return out
  out.append((t, INF))
  return out


@dataclass
class _Plan:
  t0: int
  cells: list[int]
  """Cell at t0, t0 + 1, ...; after the last one the AGV stays there (parked)."""
  keys: tuple | None
  """Stop list the plan was made for; None forces a re-plan."""
  partial: bool = False
  """Covers only the next stop (the whole list did not fit); re-planned once there."""

  @property
  def end(self) -> int:
    return self.t0 + len(self.cells) - 1

  def at(self, t: int) -> int:
    return self.cells[min(max(t - self.t0, 0), len(self.cells) - 1)]


def _keys(stops: list[Stop]) -> tuple:
  return tuple((s.order_id, s.kind) for s in stops)


class CentralPlanner:
  def __init__(self, index: RoadIndex, homes: list[int], max_expand: int = 100_000,
               home_retry: int = 30, restarts: int = 4) -> None:
    self.index = index
    self.homes = list(homes)
    self.max_expand = max_expand
    self.home_retry = home_retry
    self.restarts = restarts
    n = len(homes)
    self.plans: list[_Plan | None] = [None] * n
    self.busy: dict[int, list[tuple[int, int, int]]] = {}
    """Cell -> hard spans (start, end, AGV) of the current plans."""
    self.near: dict[tuple[int, int], int] = {}
    """(cell, t) -> how many AGVs arrive by moving at a neighbour of the cell at t."""
    self.blocked: frozenset = frozenset()
    self.failures = 0
    """AGV-ticks spent standing still because no plan was found."""
    self.deviations = 0
    """Moves the final check had to cancel (a stale plan)."""

  # -- reservations ---------------------------------------------------------------

  def _spans(self, plan: _Plan):
    """Hard (cell, start, end) visits of a plan; the parked tail is not included."""
    cells, t0 = plan.cells, plan.t0
    i = 0
    while i < len(cells) - 1:
      j = i
      while j + 1 < len(cells) - 1 and cells[j + 1] == cells[i]:
        j += 1
      yield cells[i], t0 + i, t0 + j
      i = j + 1
    # The last cell is held hard only on the tick it is reached.
    yield cells[-1], plan.end, plan.end

  def _add(self, a: int, plan: _Plan) -> None:
    self.plans[a] = plan
    for c, s, e in self._spans(plan):
      self.busy.setdefault(c, []).append((s, e, a))
    nbrs = self.index.nbrs
    for k in range(1, len(plan.cells)):
      y = plan.cells[k]
      if y != plan.cells[k - 1]:
        t = plan.t0 + k
        for c in nbrs[y]:
          self.near[(c, t)] = self.near.get((c, t), 0) + 1

  def _remove(self, a: int) -> None:
    plan = self.plans[a]
    if plan is None:
      return
    self.plans[a] = None
    for c, _, _ in self._spans(plan):
      lst = self.busy.get(c)
      if lst:
        self.busy[c] = [x for x in lst if x[2] != a]
    nbrs = self.index.nbrs
    for k in range(1, len(plan.cells)):
      y = plan.cells[k]
      if y != plan.cells[k - 1]:
        t = plan.t0 + k
        for c in nbrs[y]:
          v = self.near[(c, t)] - 1
          if v:
            self.near[(c, t)] = v
          else:
            del self.near[(c, t)]

  def _hold(self, a: int, now: int, cell: int) -> None:
    """No plan (yet): stand still. Hard for HOLD ticks; after that, hard only for the
    AGVs that list `a` in their `hard` set (see `_intervals`)."""
    self._remove(a)
    self._add(a, _Plan(now, [cell] * (HOLD + 1), None))

  def _tail(self, b: int) -> tuple[int, int] | None:
    p = self.plans[b]
    return None if p is None else (p.cells[-1], p.end)

  def _hits_tail(self, b: int, now: int) -> bool:
    """Does another AGV's hard plan use b's parking cell after b parks there?"""
    tail = self._tail(b)
    if tail is None:
      return False
    c, t = tail
    t = max(t, now)
    return any(x[2] != b and x[1] >= t for x in self.busy.get(c, ()))

  # -- one tick -------------------------------------------------------------------

  def step(self, now: int, pos: list[int], stops: list[list[Stop]],
           serving: list[tuple[Stop, int] | None], orders: dict[int, Order],
           blocked: frozenset) -> list[int]:
    """Next cell id per AGV."""
    n = len(pos)
    work: list[int] = []
    if blocked != self.blocked:
      self.blocked = blocked
      work = list(range(n))
    for a in range(n):
      p = self.plans[a]
      keys = _keys(stops[a])
      if (p is None or p.keys is None or p.at(now) != pos[a] or len(keys) > len(p.keys)
          or keys != p.keys[len(p.keys) - len(keys):]):
        work.append(a)
      elif self._hits_tail(a, now) or (p.partial and now >= p.end):
        work.append(a)
      elif (not stops[a] and now >= p.end and (now + a) % self.home_retry == 0
            and (p.cells[-1] != self.homes[a] or self._on_needed(a, p.cells[-1], stops))):
        work.append(a)
    if work:
      order = sorted(set(work), key=lambda a: (not stops[a], a))
      self._resolve(order, now, pos, stops, serving, orders)
    new = [self.plans[a].at(now + 1) for a in range(n)]
    return self._check(new, pos, serving)

  def _on_needed(self, a: int, c: int, stops) -> bool:
    ids = self.index.ids
    return any(ids[x.cell] == c for b in range(len(stops)) if b != a for x in stops[b])

  def _resolve(self, work, now, pos, stops, serving, orders) -> None:
    """Plan the AGVs in `work`, one after another. If one fails, try again with it
    first and with the AGVs that planned to drive through its cell re-planned too
    (priorities are adjusted, up to `restarts` times). Those still failing stand
    still this tick; whoever would drive through them then goes around them."""
    n = len(pos)
    ids = self.index.ids
    self._needed = [{ids[x.cell] for x in stops[b]} for b in range(n)]
    order = list(dict.fromkeys(work))
    for attempt in range(self.restarts + 1):
      for a in order:  # Not planned yet: an obstacle where it stands, for a while.
        self._hold(a, now, pos[a])
      failed: list[int] = []
      i = 0
      while i < len(order) and i < 4 * n:
        a = order[i]
        i += 1
        self._remove(a)
        plan = self._plan(a, now, pos, stops, serving, orders, set())
        if plan is None and stops[a]:
          plan = self._plan(a, now, pos, stops, serving, orders, set(), horizon=1)
        if plan is None:
          self._hold(a, now, pos[a])
          failed.append(a)
          continue
        self._add(a, plan)
        for b in range(n):  # Parked where a now drives: step aside.
          if b != a and b not in order[i:] and self._hits_tail(b, now):
            order.append(b)
      if not failed:
        return
      if attempt == self.restarts:
        break
      users = [u for f in failed for u in self._using(pos[f], now, INF, f)]
      order = list(dict.fromkeys(failed + [a for a in order if a not in failed] + users))
    # Still failing: they stand still. Whoever drives through them goes around them.
    hard = set(failed)
    for f in failed:
      self.failures += 1
      for u in self._using(pos[f], now, INF, f):
        if u in hard:
          continue
        self._remove(u)
        plan = self._plan(u, now, pos, stops, serving, orders, hard)
        if plan is None and stops[u]:
          plan = self._plan(u, now, pos, stops, serving, orders, hard, horizon=1)
        if plan is None:
          self._hold(u, now, pos[u])
          self.failures += 1
        else:
          self._add(u, plan)

  def _using(self, c: int, t0: int, t1: int, a: int) -> list[int]:
    return sorted({x[2] for x in self.busy.get(c, ()) if x[2] != a and x[0] <= t1 and x[1] >= t0})

  def _check(self, new: list[int], pos: list[int], serving) -> list[int]:
    """Cancel any move that would break the rule (a stale plan)."""
    n = len(pos)
    nbrs = self.index.nbrs

    def stop(a: int) -> None:
      new[a] = pos[a]
      self.deviations += 1
      p = self.plans[a]
      if p is not None:
        p.keys = None

    changed = True
    while changed:
      changed = False
      for a in range(n):
        if new[a] != pos[a] and (serving[a] is not None or new[a] in self.blocked
                                 or new[a] not in nbrs[pos[a]]):
          stop(a)
          changed = True
      where: dict[int, int] = {}
      for a in range(n):
        b = where.get(new[a])
        if b is not None:
          stop(a if new[a] != pos[a] else b)
          changed = True
          break
        where[new[a]] = a
      if changed:
        continue
      movers = [a for a in range(n) if new[a] != pos[a]]
      for i, a in enumerate(movers):
        for b in movers[i + 1:]:
          if (new[a] == pos[b] and new[b] == pos[a]) or new[b] in nbrs[new[a]]:
            stop(b)
            changed = True
            break
        if changed:
          break
    return new

  # -- planning one AGV -----------------------------------------------------------

  def _intervals(self, c: int, hard: set[int], cache: dict, start: int | None = None,
                 now: int = 0) -> list[tuple[int, int]]:
    got = cache.get(c)
    if got is not None:
      return got
    if c in self.blocked and c != start:
      cache[c] = []
      return []
    spans = [(s, e) for s, e, _ in self.busy.get(c, ())]
    t_now = cache.get("__now__", now)
    for t in cache.get("__parked__", {}).get(c, ()):
      # A parked AGV gets HOLD ticks to step aside before anyone drives in.
      spans.append((max(t, t_now), max(t, t_now) + HOLD))
    for b in hard:
      p = self.plans[b]
      if p is not None and p.keys is None and p.cells[-1] == c:
        spans.append((p.t0, INF))  # It could not move out of our way.
    if c == start:
      spans = [(s, e) for s, e in spans if not s <= now <= e]  # Stale: we stand here.
    got = safe_intervals(spans, now)
    cache[c] = got
    return got

  def _plan(self, a, now, pos, stops, serving, orders, hard,
            horizon: int | None = None) -> _Plan | None:
    """Timed plan over the stop list, then to a parking cell. `horizon`: plan only
    that many stops and stop there (no parking leg): a fallback when the whole list
    cannot be fitted around the other plans, since legs are planned one after
    another without backtracking."""
    keys = _keys(stops[a])
    start = pos[a]
    cache: dict = {"__parked__": {}, "__now__": now}
    for b, p in enumerate(self.plans):
      if b != a and p is not None and p.keys is not None:
        cache["__parked__"].setdefault(p.cells[-1], []).append(p.end)
    ivs = self._intervals(start, hard, cache, start=start, now=now)
    cur_e = next(e for s, e in ivs if s <= now <= e)
    cells = [start]
    t = now
    rest = list(stops[a])
    if serving[a] is not None:
      x, end = serving[a]
      if x in rest:
        rest.remove(x)
      if cur_e < end:
        return None
      cells += [start] * (end - now)
      t = end
    partial = horizon is not None and len(rest) > horizon
    if partial:
      rest = rest[:horizon]
    for s in rest:
      o = orders.get(s.order_id)
      goal = self.index.ids[s.cell]
      early = o.arrival if (o is not None and s.kind == "pick") else 0
      d = dwell(o) if (o is not None and s.kind != "via") else 0

      def done_by(g: int, early=early, d=d) -> int:
        return max(g, early) + d

      if goal == cells[-1]:
        end = done_by(t)
        if cur_e < end:
          return None
        cells += [goal] * (end - t)
        t = end
        continue
      got = self._sipp(a, cells[-1], t, cur_e, goal, lambda c, g, e, goal=goal, f=done_by:
                       c == goal and e >= f(g), hard, cache, terminal=True)
      if got is None:
        return None
      path, cur_e = got
      t += len(path)
      cells += path
      end = done_by(t)
      cells += [goal] * (end - t)
      t = end
    if partial:
      return _Plan(now, cells, keys, partial=True)
    path = self._park(a, cells[-1], t, cur_e, hard, cache)
    if path is None:
      return None
    cells += path
    return _Plan(now, cells, keys)

  def _park(self, a, here, t, cur_e, hard, cache) -> list[int] | None:
    """Cells after t to a parking cell nobody needs later: home if possible. None if
    there is no such cell within reach."""
    tails = {self._tail(b)[0] for b in range(len(self.plans))
             if b != a and self.plans[b] is not None}
    # Never park on a stop another AGV still has to reach: it might not get out.
    needed = set().union(*(x for b, x in enumerate(getattr(self, "_needed", ())) if b != a))

    def ok(c, g, e):
      return e >= INF and c not in tails and c not in needed

    home = self.homes[a]
    if here == home and ok(here, t, cur_e):
      return []
    got = self._sipp(a, here, t, cur_e, home, lambda c, g, e: c == home and ok(c, g, e),
                     hard, cache, terminal=False)
    if got is not None:
      return got[0]
    if ok(here, t, cur_e):
      return []
    got = self._sipp(a, here, t, cur_e, None, ok, hard, cache, terminal=False)
    return None if got is None else got[0]

  def _sipp(self, a, start, t0, e0, target, goal, hard, cache, terminal):
    """Earliest timed path from (start, t0) to a state where goal(cell, t, e) holds.
    Returns (cells at t0 + 1, ..., arrival), safe-interval end at arrival) or None.
    `terminal`: the target may only be entered to stop there (a stop is served the
    moment the AGV stands on it)."""
    ix = self.index
    nbrs, zone = ix.nbrs, ix.zone
    table = ix.dist_to(target) if target is not None else None
    if table is not None and table[start] >= UNREACHABLE:
      return None
    own = {zone[start], zone[target] if target is not None else -1}
    near = self.near
    root = (start, -1)
    best = {root: t0}
    parent: dict = {}
    h0 = table[start] if table is not None else 0
    heap = [(t0 + h0, t0, start, e0, root)]
    expanded = 0
    first = True
    while heap:
      _, g, c, e, key = heapq.heappop(heap)
      if g > best[key]:
        continue
      if not first and goal(c, g, e):
        return self._unwind(parent, key, t0), e
      if not first and terminal and c == target:
        continue  # Would pass through its own stop.
      first = False
      expanded += 1
      if expanded > self.max_expand:
        return None
      for nb in nbrs[c]:
        if table is not None and table[nb] >= UNREACHABLE:
          continue
        if zone[nb] >= 0 and zone[nb] not in own and target is not None:
          continue
        for s2, e2 in self._intervals(nb, hard, cache):
          if s2 > e + 1:
            break
          if e2 < g + 1:
            continue
          tt = max(g + 1, s2)
          hi = min(e + 1, e2)
          while tt <= hi and (nb, tt) in near:
            tt += 1
          if tt > hi:
            continue
          k2 = (nb, s2)
          if tt < best.get(k2, INF):
            best[k2] = tt
            parent[k2] = (key, tt)
            h = table[nb] if table is not None else 0
            heapq.heappush(heap, (tt + h, tt, nb, e2, k2))
    return None

  @staticmethod
  def _unwind(parent, key, t0) -> list[int]:
    """Cells at t0 + 1 ... arrival, waits included."""
    hops = []
    while key in parent:
      prev, tt = parent[key]
      hops.append((key[0], tt))
      key = prev
    hops.reverse()
    cells: list[int] = []
    here, t = key[0], t0
    for cell, tt in hops:
      cells += [here] * (tt - 1 - t)
      cells.append(cell)
      here, t = cell, tt
    return cells
