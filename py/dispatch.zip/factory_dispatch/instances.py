"""Randomized problem instances for training, and the scale-test instances (spec 4.8)."""

from __future__ import annotations

import random
from dataclasses import dataclass, field

from factory_dispatch.blocks import Block, block_schedule
from factory_dispatch.fleet import fleet_homes
from factory_dispatch.insertion import Rules, dwell
from factory_dispatch.orders import Order, generate_shift
from factory_dispatch.traffic import UNREACHABLE, RoadIndex
from factory_layout import FactoryLayout, build_road_graph, generate_layout, load_layout
from factory_layout.layout import Cell

LAMBDAS = (0.0, 0.03, 0.1, 0.3, 1.0, 3.0)
BLOCK_RATES = (0.0, 4.0, 8.0)
TRAIN_SHIFT = 3600
EMPTY_SAMPLE = 50
MIN_CELLS_PER_AGV = 60
"""Densest fleet allowed: map1a's 4 AGVs on 259 road cells, the densest set-up in the
real data (map3a: 214 cells per AGV). Packing more AGVs into a small map is not the
real problem (author, 2026-11-07)."""


def road_cells(layout: FactoryLayout) -> int:
  return int((layout.grid == 1).sum())


def max_fleet(layout: FactoryLayout) -> int:
  return road_cells(layout) // MIN_CELLS_PER_AGV


def nominal_fleet(layout: FactoryLayout) -> int:
  """Reference fleet: one AGV per store, within the density limit. Gives the real
  maps' own fleets (map1a 4, map2a 4, map3a 22)."""
  return max(1, min(len(layout.stores), max_fleet(layout)))


def utilization(layout: FactoryLayout, n_agv: int, orders: list[Order], shift: int,
                index: RoadIndex | None = None) -> float:
  """Estimated busy share of the fleet: per order the loaded leg, an empty leg from
  a typical drop to the pickup, and both dwells, over fleet x shift seconds."""
  if not orders:
    return 0.0
  index = index or RoadIndex(build_road_graph(layout))
  drops = sorted({o.dropoff for o in orders})
  rng = random.Random(0)
  sample = rng.sample(drops, min(EMPTY_SAMPLE, len(drops)))
  # Empty leg: the nearest of about half the fleet (the free AGVs), taken as the
  # 1/(n/2 + 1) quantile of drop-to-pickup distances. Calibrated so map1a (4 AGVs)
  # and map3a (22) both saturate near rho = 1 (measured: loads 0.18 and 0.35).
  q = 1.0 / (max(1.0, n_agv / 2) + 1)
  work = 0.0
  empty: dict[Cell, float] = {}
  for o in orders:
    table = index.dist_to(index.ids[o.dropoff])
    loaded = table[index.ids[o.pickup]]
    if o.pickup not in empty:
      tp = index.dist_to(index.ids[o.pickup])
      legs = sorted(tp[index.ids[d]] for d in sample if tp[index.ids[d]] < UNREACHABLE)
      empty[o.pickup] = legs[min(len(legs) - 1, int(q * len(legs)))] if legs else 0.0
    work += (loaded if loaded < UNREACHABLE else 0) + empty[o.pickup] + 2 * dwell(o)
  return work / (n_agv * shift)


def load_for_utilization(layout: FactoryLayout, n_agv: int, rho: float, seed: int,
                         shift: int, index: RoadIndex | None = None) -> float:
  """Order-rate multiplier giving estimated utilization `rho` (two secant steps)."""
  index = index or RoadIndex(build_road_graph(layout))
  load = 0.2
  for _ in range(2):
    got = utilization(layout, n_agv, generate_shift(layout, seed, load=load, shift=shift),
                      shift, index)
    if got <= 0:
      return load
    load *= rho / got
  return load


@dataclass
class Instance:
  layout: FactoryLayout
  homes: list[Cell]
  orders: list[Order]
  blocks: list[Block]
  rules: Rules
  shift: int
  meta: dict = field(default_factory=dict)


def make_instance(layout: FactoryLayout, n_agv: int, rho: float, lam: float,
                  block_rate: float, seed: int, shift: int, **meta) -> Instance:
  if n_agv > max_fleet(layout):
    raise ValueError(f"{layout.name}: {n_agv} AGVs on {road_cells(layout)} road cells is "
                     f"denser than {MIN_CELLS_PER_AGV} cells per AGV")
  index = RoadIndex(build_road_graph(layout))
  load = load_for_utilization(layout, n_agv, rho, seed, shift, index)
  orders = generate_shift(layout, seed, load=load, shift=shift)
  return Instance(
    layout, fleet_homes(layout, n_agv), orders,
    block_schedule(layout, seed, block_rate, shift), Rules(True, lam), shift,
    {"layout": layout.name, "agvs": n_agv, "rho": rho, "load": load, "lam": lam,
     "road_cells": road_cells(layout),
     "block_rate": block_rate, "seed": seed, **meta},
  )


def train_layout(rng: random.Random, seed: int, stretch: bool = False) -> FactoryLayout:
  """stretch (splits ending in "2"): half the generated layouts get longer blocks
  and connector spacing, so training sees map3a-like distances (2026-11-07: a
  policy trained on compact layouts deferred almost everything on map3a)."""
  u = rng.random()
  if u < 0.2:
    return load_layout("map1a")
  if u < 0.3:
    return load_layout("map2a")
  # 2026-11-08: larger than before (3-8 lines, 2-3 aisles) so the density limit still
  # leaves fleets up to about 15 AGVs.
  lines, spl, aisles = rng.randint(4, 16), rng.randint(2, 4), rng.randint(2, 4)
  if stretch and rng.random() < 0.6:
    return generate_layout(seed, lines, spl, aisles, block=rng.randint(12, 40),
                           step=rng.randint(16, 60))
  return generate_layout(seed, lines, spl, aisles)


LARGE_LAYOUT_SEED = 10**6
"""Offset of the layout seeds of the large split, so a training layout never equals
a generated evaluation layout (those use the instance seed itself)."""


def large_layout(rng: random.Random, seed: int) -> FactoryLayout:
  """Splits ending in "3" (frame B, 2026-11-19): only large generated layouts, nominal
  fleets of about 12 to 30 AGVs (train2 rarely reached 12; map3a runs 11 to 22)."""
  lines, spl, aisles = rng.randint(22, 36), rng.randint(3, 4), rng.randint(3, 6)
  s = LARGE_LAYOUT_SEED + seed
  if rng.random() < 0.6:
    return generate_layout(s, lines, spl, aisles, block=rng.randint(12, 40),
                           step=rng.randint(16, 60))
  return generate_layout(s, lines, spl, aisles)


def sample_instance(seed: int, split: str = "train") -> Instance:
  """One randomized training (or validation) episode. Never uses map3a."""
  rng = random.Random(f"instance-{split}-{seed}")
  layout = (large_layout(rng, seed) if split.endswith("3")
            else train_layout(rng, seed, stretch=split.endswith("2")))
  # As in the minimum-fleet evaluation: demand set on the nominal fleet, then a
  # fleet of half to all of it, so training covers under-provisioned fleets.
  n_ref = nominal_fleet(layout)
  n_agv = rng.randint(max(1, -(-n_ref // 2)), n_ref)
  inst = make_instance(
    layout, n_ref, rng.uniform(0.35, 0.65), rng.choice(LAMBDAS), rng.choice(BLOCK_RATES),
    seed, TRAIN_SHIFT, split=split, n_ref=n_ref,
  )
  inst.homes = fleet_homes(layout, n_agv)
  inst.meta["agvs"] = n_agv
  return inst


SCALE_AXES = {
  "fleet": [("map3a", n) for n in (5, 11, 22, 30, 44)],
  # None: the layout's nominal fleet. The old 22 / 44 / 88-AGV generated cases were
  # about 30 road cells per AGV and gridlocked; dropped 2026-11-08.
  "network": [("map1a", None), ("map2a", None), ("map3a", None), ((22, 3, 3), None),
              ((22, 3, 6), None), ((22, 3, 9), None)],
  "stations": [((20, 3, 4), None), ((30, 4, 6), None), ((40, 6, 8), None)],
}


def scale_instances(axis: str, seed: int, rho: float = 0.85, lam: float = 0.1,
                    block_rate: float = 4.0, shift: int = 3600) -> list[Instance]:
  """Test instances along one axis of spec 4.8. Seeds >= 1000 are test seeds."""
  out = []
  for spec, n_agv in SCALE_AXES[axis]:
    layout = load_layout(spec) if isinstance(spec, str) else generate_layout(seed, *spec)
    n_agv = n_agv or nominal_fleet(layout)
    out.append(make_instance(layout, n_agv, rho, lam, block_rate, seed, shift,
                             axis=axis))
  return out
