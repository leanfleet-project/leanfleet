"""Rollout planner (frame B teacher, 2026-11-17): one-step look-ahead with a base policy.

At a decision with pending orders, the most urgent order (earliest deadline) gets up to
`options - 1` candidate AGVs, cheapest insertion first, plus "not now"; the other
pending orders go as the base policy puts them (`wm.branch.candidates`, the options of
the gates). Each option runs a branch of the simulator for `horizon` ticks with a fresh
base policy, under `futures` sampled futures; the option with the lowest mean J at
now + horizon (`wm.hybrid.j_until`) is applied. Ties go to the cheaper option.

Online: a branch never sees the run's own future. Orders not arrived yet are replaced
by dynamic orders of another shift drawn with the same generator, layout and load
(`wm.branch.future_orders`); road blocks not started yet by another block schedule;
blocks already on are assumed to last `MEDIAN_SEC` from their start (at least
`MIN_LEFT` more seconds), since their real end is unknown. All options share the
same futures (common random numbers), drawn from (seed, instance seed, tick, future).

Latency: the insertion evaluations of the branches are counted by the simulator like
any dispatcher's; the rest of the branch work is `extra_sec` = simulated AGV-ticks
times `sec_per_tick`.
"""

from __future__ import annotations

import dataclasses
import random
import re

from factory_dispatch.baselines import NearestDispatcher, ReserveNearest
from factory_dispatch.blocks import MEDIAN_SEC, block_schedule
from factory_dispatch.sim import Dispatcher
from factory_dispatch.insertion import best_insertion
from factory_dispatch.wm.branch import future_orders
from factory_dispatch.wm.hybrid import j_until

SEC_PER_TICK = 4e-5
"""Seconds of simulator work per AGV and simulated tick, besides insertion evaluations
(the largest of reserve1 runs on map1a, map3a, g22x3x6, seed 400, 2026-11-17:
4.6e-6 to 3.9e-5; `scripts/calibrate_tick.py`)."""
MIN_LEFT = 60


def base_policy(name: str) -> Dispatcher:
  if name == "nearest":
    return NearestDispatcher()
  m = re.fullmatch(r"reserve(\d+)", name)
  if m:
    return ReserveNearest(int(m[1]))
  raise ValueError(name)


def parse_roll(config: str) -> dict:
  """`roll_b<base>_h<horizon>_k<futures>_o<options>[_w<red penalty>][_r][_c[k]]@<latency>`
  (`_r`: red orders follow the base policy; `_c`: only AGVs the reserve base allows;
  `_c<k>`: only AGVs holding fewer than k orders)."""
  m = re.fullmatch(
    r"roll_b([a-z]+\d*)_h(\d+)_k(\d+)_o(\d+)(?:_w(\d+(?:\.\d+)?))?(_r)?(_c\d*)?@[LF0]",
    config)
  if m is None:
    raise ValueError(config)
  out = dict(base=m[1], horizon=int(m[2]), futures=int(m[3]), options=int(m[4]))
  if m[5] is not None:
    out["red_penalty"] = float(m[5])
  if m[6]:
    out["red_base"] = True
  if m[7]:
    out["cap"] = int(m[7][2:]) if len(m[7]) > 2 else True
  return out


def red_late(sim, t: int) -> int:
  """Red orders arrived by now with a deadline at or before tick `t` that were not
  delivered by their deadline (judged at `t`)."""
  s = sim.state
  done = s.done
  return sum(1 for o in sim.orders[:s.next_order]
             if o.priority == 1 and o.deadline <= t
             and (done.get(o.id) is None or done[o.id] > o.deadline))


class RolloutDispatcher(Dispatcher):
  def __init__(self, base: str = "reserve1", horizon: int = 600, futures: int = 2,
               options: int = 5, red_penalty: float = 0.0, sec_per_tick: float = SEC_PER_TICK,
               seed: int = 0, red_base: bool = False, cap: bool | int = False) -> None:
    """`red_penalty`: J units added to a branch's score per red order late by the cut
    (the planner's own score; the run is still judged by J and the service target).
    `red_base`: red orders are never the focal order; they go as the base policy
    puts them, and the focal is the most urgent yellow or green order.
    `cap`: a yellow or green focal order is only offered to AGVs holding fewer than
    k orders (and "not now"): True, k of the reserve<k> base (the planner only refines
    the base's choices and keeps its room for red orders); an int, that k."""
    base_policy(base)
    self.red_penalty, self.red_base, self.cap = red_penalty, red_base, cap
    m = re.fullmatch(r"reserve(\d+)", base)
    self.limit = (cap if not isinstance(cap, bool) else int(m[1]) if m else None) if cap \
      else None
    self.base, self.horizon, self.futures, self.options = base, horizon, futures, options
    self.sec_per_tick, self.seed = sec_per_tick, seed
    self.sim = self.inst = None
    self.extra_sec = 0.0
    self.ticks = self.last_ticks = self.rollouts = 0

  def bind(self, sim, inst) -> None:
    """The run this dispatcher decides for (branches clone it) and its instance."""
    self.sim, self.inst = sim, inst

  def _rng_seed(self, now: int, f: int) -> int:
    return random.Random(f"roll-{self.seed}-{self.inst.meta.get('seed')}-{now}-{f}"
                         ).randrange(10**9)

  def branch_blocks(self, now: int, f: int) -> list:
    """Blocks a branch at `now` sees in future `f`."""
    on = [dataclasses.replace(b, end=max(b.start + MEDIAN_SEC, now + MIN_LEFT))
          for b in self.sim.blocks if b.start <= now < b.end]
    rate = self.inst.meta.get("block_rate", 4.0)
    new = [b for b in block_schedule(self.inst.layout, self._rng_seed(now, f), rate,
                                     self.inst.shift) if b.start > now]
    return on + new

  def _branch_futures(self, now: int):
    s = self.sim.state
    return [(future_orders(self.inst.layout, self.inst.meta["load"], self.inst.shift, now,
                           seed=self._rng_seed(now, f), first_id=s.next_order),
             self.branch_blocks(now, f)) for f in range(self.futures)]

  def _value(self, pairs, fut, blocks, until: int) -> tuple[float, int]:
    sim = self.sim
    rec, sim.recorders = sim.recorders, []
    try:
      disp = base_policy(self.base)
      b = sim.clone(dispatcher=disp, future=fut)
    finally:
      sim.recorders = rec
    b.blocks = blocks
    now = b.state.now
    v = b.step(list(pairs))
    while v is not None and b.state.now < until:
      v = b.step(disp.decide(v))
    score = j_until(b, until)
    if self.red_penalty:
      score += self.red_penalty * red_late(b, until)
    return score, (b.state.now - now) * len(b.state.pos)

  def _options(self, view):
    """(focal order id or None, options); one option (the base policy's pairs) when
    there is nothing to choose."""
    base = base_policy(self.base)
    pool = [o for o in view.pending if not (self.red_base and o.priority == 1)]
    if not pool:
      return None, [base.decide(view)]
    focal = min(pool, key=lambda o: (o.deadline, o.id))
    costs = []
    for a in view.agvs:
      if (self.limit is not None and focal.priority != 1
          and len({x.order_id for x in a.stops}) >= self.limit):
        continue
      ins = best_insertion(a.cell, a.stops, a.load, focal, view.now, view.index, view.q,
                           view.orders, rules=view.rules)
      if ins is not None:
        costs.append((ins.cost, a.id))
    agvs = [a for _, a in sorted(costs)[:self.options - 1]] + [None]
    pairs = base.decide(view)
    if len(agvs) < 2:
      return focal.id, [pairs]
    rest = [p for p in pairs if p[0] != focal.id]
    return focal.id, [rest + ([(focal.id, a)] if a is not None else []) for a in agvs]

  def decide(self, view):
    self.extra_sec, self.last_ticks = 0.0, 0
    if not view.pending:
      return base_policy(self.base).decide(view)
    _, options = self._options(view)
    if len(options) < 2:
      return options[0]
    now = view.now
    until = now + self.horizon
    futs = self._branch_futures(now)
    scores = []
    for opt in options:
      total = 0.0
      for fut, blocks in futs:
        j, t = self._value(opt, fut, blocks, until)
        total += j
        self.last_ticks += t
      scores.append(total / len(futs))
    self.sim.index.set_blocked(self.sim.state.closed)
    self.ticks += self.last_ticks
    self.rollouts += 1
    self.extra_sec = self.last_ticks * self.sec_per_tick
    best = min(range(len(options)), key=lambda i: (scores[i], i))
    return options[best]
