"""Undirected road graph. Roads are one lane wide and two-way."""

from __future__ import annotations

from collections import deque
from collections.abc import Collection
from dataclasses import dataclass

from factory_layout.layout import Cell, FactoryLayout


@dataclass(frozen=True)
class RoadEdge:
  u: int
  v: int
  cells: list[Cell]
  length: float


class RoadGraph:
  """Contracted graph: nodes are junctions, dead ends, stores and stations."""

  def __init__(self, layout: FactoryLayout) -> None:
    self.layout = layout
    grid = layout.grid
    road = {(int(r), int(c)) for r, c in zip(*(grid == 1).nonzero())}
    self._nbrs: dict[Cell, list[Cell]] = {
      (r, c): [
        n for n in ((r + 1, c), (r - 1, c), (r, c + 1), (r, c - 1)) if n in road
      ]
      for r, c in road
    }
    self._component: dict[Cell, int] = {}
    for start in sorted(road):
      if start in self._component:
        continue
      label = len(set(self._component.values()))
      self._component[start] = label
      queue = deque([start])
      while queue:
        for n in self._nbrs[queue.popleft()]:
          if n not in self._component:
            self._component[n] = label
            queue.append(n)

    named = {
      c
      for group in (layout.stores, layout.stations)
      for cells in group.values()
      for c in cells
      if c in road
    }
    node_set = {c for c in road if len(self._nbrs[c]) != 2} | named
    # A component that is a plain ring has no natural node: pin one.
    covered = {self._component[c] for c in node_set}
    for c in sorted(road):
      if self._component[c] not in covered:
        node_set.add(c)
        covered.add(self._component[c])

    self.nodes: list[Cell] = sorted(node_set)
    index = {c: i for i, c in enumerate(self.nodes)}
    self.edges: list[RoadEdge] = []
    seen: set[frozenset[Cell]] = set()
    for a in self.nodes:
      for first in self._nbrs[a]:
        if frozenset((a, first)) in seen:
          continue
        cells = [a, first]
        while cells[-1] not in node_set:
          cells.append(next(n for n in self._nbrs[cells[-1]] if n != cells[-2]))
        for p, q in zip(cells, cells[1:]):
          seen.add(frozenset((p, q)))
        self.edges.append(
          RoadEdge(index[a], index[cells[-1]], cells, (len(cells) - 1) * layout.cell)
        )

  def component_of(self, cell: Cell) -> int:
    return self._component[cell]

  def all_cells(self) -> list[Cell]:
    return list(self._nbrs)

  def neighbours(self, cell: Cell) -> list[Cell]:
    return self._nbrs[cell]

  def shortest_path(
    self, a: Cell, b: Cell, blocked: Collection[Cell] = ()
  ) -> list[Cell]:
    """Cell path from a to b that never enters a blocked cell.

    Raises ValueError if b cannot be reached.
    """
    if self._component[a] != self._component[b]:
      raise ValueError(f"no route from {a} to {b}: different road components")
    prev: dict[Cell, Cell | None] = {a: None}
    queue = deque([a])
    while queue:
      c = queue.popleft()
      if c == b:
        break
      for n in self._nbrs[c]:
        if n not in prev and n not in blocked:
          prev[n] = c
          queue.append(n)
    if b not in prev:
      raise ValueError(f"no route from {a} to {b}: blocked")
    path = [b]
    while (p := prev[path[-1]]) is not None:
      path.append(p)
    return path[::-1]


def build_road_graph(layout: FactoryLayout) -> RoadGraph:
  return RoadGraph(layout)
