"""Grid layouts: def layer 0 wall, 1 road, 2 machine, 3/4 store zone, 8 floor."""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

MAPS_DIR = Path(__file__).parent / "maps"
# AGV_ORIENT codes: 0 right, 1 up, 2 left, 3 down.
_YAW = {0: 0.0, 1: math.pi / 2, 2: math.pi, 3: -math.pi / 2}

Cell = tuple[int, int]  # (row, col)


@dataclass(frozen=True)
class FactoryLayout:
  name: str
  cell: float
  grid: np.ndarray
  tsm: np.ndarray
  stores: dict[str, list[Cell]]
  stations: dict[str, list[Cell]]
  transfers: dict[str, list[Cell]]
  agv_yaw: list[float]
  agv_orient: list[int] = field(default_factory=list)
  agv_routes: list[list[int]] = field(default_factory=list)
  """Turn codes of the fixed-route layouts: 1 straight, 2 left, 3 right."""

  @property
  def height(self) -> int:
    return self.grid.shape[0]

  @property
  def width(self) -> int:
    return self.grid.shape[1]

  def cell_to_world(self, row: int, col: int) -> tuple[float, float]:
    return (
      (col + 0.5 - self.width / 2) * self.cell,
      (self.height / 2 - row - 0.5) * self.cell,
    )


def load_layout(name: str, cell: float = 1.0) -> FactoryLayout:
  with np.load(MAPS_DIR / f"{name}.npz", allow_pickle=False) as f:
    grid, tsm, pup, orient = f["def"], f["tsm"], f["pup"], f["agv_orient"]
    routes = [
      [int(v) for v in f[f"route_{i}"]]
      for i in range(len(orient))
      if f"route_{i}" in f.files
    ]
  stores: dict[str, list[Cell]] = {}
  stations: dict[str, list[Cell]] = {}
  transfers: dict[str, list[Cell]] = {}
  for r, c in zip(*np.nonzero(pup != "0")):
    label = str(pup[r, c])
    group = stores if label.isdigit() else transfers if label[0] == "T" else stations
    # A label can mark several cells (map3 has 22A twice), so keep them all.
    group.setdefault(label, []).append((int(r), int(c)))
  return FactoryLayout(
    name,
    cell,
    grid,
    tsm,
    stores,
    stations,
    transfers,
    [_YAW[int(d)] for d in orient],
    [int(d) for d in orient],
    routes,
  )
