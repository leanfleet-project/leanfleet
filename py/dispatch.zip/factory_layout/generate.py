"""Parametric factory-like layouts for randomized training and scale tests.

Shape: `aisles` horizontal one-lane aisles, BLOCK + 1 rows apart. Vertical
connectors sit every CONNECTOR_STEP columns; the two outer ones are always kept and
each inner one is kept with probability P_CONNECTOR in each gap. Machine blocks fill
the space between them. Stations sit on aisles or at the end of short dead-end
spurs. Stores sit on extra connector columns at the right end. Roads stay one lane
wide: no 2x2 block of road cells.
"""

from __future__ import annotations

import math
import random

import numpy as np

from factory_layout.layout import Cell, FactoryLayout

WALL, ROAD, MACHINE, STORE_ZONE, FLOOR = 0, 1, 2, 3, 8
BLOCK = 9
CONNECTOR_STEP = 12
SLOT_STEP = 3
P_CONNECTOR = 0.7
P_SPUR = 0.3
SPUR_LEN = (2, 4)
STORES_PER_GAP = 4


def generate_layout(
  seed: int, lines: int, stations_per_line: int, aisles: int, name: str | None = None,
  block: int = BLOCK, step: int = CONNECTOR_STEP,
) -> FactoryLayout:
  """`block`: machine-block height between aisles (rows). `step`: columns between
  connector positions. Larger values stretch every distance in the layout."""
  if aisles < 2 or lines < 1 or stations_per_line < 1:
    raise ValueError("need aisles >= 2, lines >= 1, stations_per_line >= 1")
  if block < 5 or step < 6:
    raise ValueError("need block >= 5 and step >= 6")
  rng = random.Random(f"layout-{seed}-{lines}-{stations_per_line}-{aisles}"
                      + ("" if (block, step) == (BLOCK, CONNECTOR_STEP) else f"-{block}-{step}"))
  per_gap = (block - 1) // 2
  n_stations = lines * stations_per_line
  width = step * max(3, math.ceil(n_stations * CONNECTOR_STEP / (2 * aisles * step)))
  gaps = aisles - 1
  store_cols = math.ceil(lines / (per_gap * gaps))
  x0 = 2
  x1 = x0 + width
  xs = [x1 + 3 + 3 * j for j in range(store_cols)]
  rows = [2 + k * (block + 1) for k in range(aisles)]
  h = rows[-1] + 3
  w = xs[-1] + 3
  grid = np.full((h, w), FLOOR, dtype=np.int64)
  grid[0, :] = grid[-1, :] = WALL
  grid[:, 0] = grid[:, -1] = WALL
  grid[rows[0] - 1 : rows[-1] + 2, x1 + 1 : w - 1] = STORE_ZONE

  conn_pos = list(range(x0, x1 + 1, step))
  for k in range(gaps):
    top, bot = rows[k], rows[k + 1]
    grid[top + 2 : bot - 1, x0 + 2 : x1 - 1] = MACHINE
    for c in conn_pos:
      if c in (x0, x1) or rng.random() < P_CONNECTOR:
        grid[top + 1 : bot, c] = ROAD
        for side in (c - 1, c + 1):
          if x0 < side < x1:
            grid[top + 1 : bot, side] = FLOOR
    for c in xs:
      grid[top + 1 : bot, c] = ROAD
  for y in rows:
    grid[y, x0 : xs[-1] + 1] = ROAD

  slots = [
    (k, c)
    for k in range(aisles)
    for c in range(x0 + 3, x1 - 2, SLOT_STEP)
    if all(abs(c - p) > 1 for p in conn_pos)
  ]
  if len(slots) < n_stations:
    raise ValueError("layout too small for its stations")
  chosen = sorted(rng.sample(slots, n_stations))
  stations: dict[str, list[Cell]] = {}
  for i, (k, c) in enumerate(chosen):
    y = rows[k]
    cell = (y, c)
    if rng.random() < P_SPUR:
      sign = 1 if k < aisles - 1 else -1
      length = rng.randint(*SPUR_LEN)
      for d in range(1, length + 1):
        yy = y + sign * d
        grid[yy, c] = ROAD
        grid[yy, c - 1] = grid[yy, c + 1] = FLOOR
      cell = (y + sign * length, c)
    stations[f"{i // stations_per_line + 1}{chr(65 + i % stations_per_line)}"] = [cell]

  stores: dict[str, list[Cell]] = {}
  spots = [
    (rows[k] + 2 * (j + 1), c)
    for c in xs
    for k in range(gaps)
    for j in range(per_gap)
  ]
  for n in range(lines):
    stores[str(n + 1)] = [spots[n]]

  return FactoryLayout(
    name or f"gen_{seed}_{lines}x{stations_per_line}x{aisles}"
    + ("" if (block, step) == (BLOCK, CONNECTOR_STEP) else f"_b{block}s{step}"),
    1.0,
    grid,
    np.zeros_like(grid),
    stores,
    stations,
    {},
    [0.0] * lines,
    [0] * lines,
  )
